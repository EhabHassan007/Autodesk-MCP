[CmdletBinding()]
param(
    [ValidateSet('Status', 'Install', 'Update', 'Test', 'Collect', 'TeamStatus', 'CheckUpdate', 'EnableNotifications', 'DisableNotifications', 'ConnectGitHub', 'UninstallAutoCadPanel')]
    [string]$Action = 'Status',

    [ValidateSet('All', 'AutoCAD', 'Revit')]
    [string]$Product = 'All',

    [string]$RepositoryUrl = 'https://github.com/EhabHassan007/Autodesk-MCP.git',

    [string]$ReleaseManifestUrl = 'https://github.com/EhabHassan007/Autodesk-MCP-Releases/releases/latest/download/latest.json',

    [string]$RepositoryPath = (Join-Path $env:LOCALAPPDATA 'BIM-CAD-MCP'),

    [switch]$SkipRepositoryUpdate,

    [switch]$LibraryOnly,

    [switch]$InstallGitIfMissing,

    [switch]$InstallClaudeDesktopIfMissing,

    [string]$EnrollmentPath = '',

    # Typed by the person in the team join dialog; joining needs no team code.
    [string]$JoinName = '',

    [string]$JoinEmail = '',

    # Version of the terms of use the person accepted in the setup window; sent when joining the team.
    [string]$TermsVersion = '',

    # Choices from the setup window. Empty means: the choices saved by the last setup, else everything.
    # AiClients is a comma-separated list of ClaudeDesktop, ClaudeCode and Codex.
    [string]$AiClients = '',

    [ValidateSet('', 'On', 'Off')]
    [string]$Skills = '',

    [ValidateSet('', 'On', 'Off')]
    [string]$AutoUpdates = ''
)

$ErrorActionPreference = 'Stop'
$updateStateDirectory = Join-Path $env:LOCALAPPDATA 'AutodeskMcpConnector'
$updateStatePath = Join-Path $updateStateDirectory 'update-state.json'
$installChoicesPath = Join-Path $updateStateDirectory 'install-choices.json'
$script:ProductGiven = $PSBoundParameters.ContainsKey('Product')
$script:AllAiClients = @('ClaudeDesktop', 'ClaudeCode', 'Codex')
# The team skill service PCs join (same as TeamJoin.ServiceUrl in SetupWizard.cs).
$script:TeamServiceUrl = 'https://autodesk-skill-service.autodesk-skills-ehabhassan007.workers.dev'
$updateTaskName = 'Autodesk MCP Connector Update Alerts'

function Write-Step {
    param([string]$Message)
    Write-Host ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $Message)
}

# Machine-readable progress for the setup window (SetupWizard.ps1 ConvertFrom-SetupOutputLine).
function Write-InstallPhase {
    param([string]$Step)
    $script:CurrentInstallStep = $Step
    Write-Host ("[PHASE] {0}" -f $Step)
}

# Runs one install step so that its failure is reported against the step that was running and
# the remaining steps still run. Setup exits with an error at the end if any step failed.
$script:FailedInstallSteps = New-Object System.Collections.Generic.List[string]
function Invoke-InstallStep {
    param([string]$Step, [scriptblock]$Body)
    Write-InstallPhase $Step
    try { & $Body }
    catch {
        $failedStep = if ($script:CurrentInstallStep) { $script:CurrentInstallStep } else { $Step }
        Write-Step ("{0} failed: {1}" -f $failedStep, $_.Exception.Message)
        Write-InstallResult $failedStep 'failed' 'see the setup log'
        $script:FailedInstallSteps.Add($failedStep)
    }
}

# Which AI apps to connect, which Autodesk programs to set up and whether to install the team skills.
# Values given on the command line (the setup window) win and are saved; Update and Repair reuse the saved
# choices; with nothing saved, everything is set up as before.
function Get-InstallChoices {
    param([string]$AiClients = '', [string]$Product = 'All', [bool]$ProductGiven = $false, [string]$Skills = '', [string]$Path = $installChoicesPath)
    $saved = $null
    if (Test-Path -LiteralPath $Path -PathType Leaf) { try { $saved = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json } catch { $saved = $null } }
    $clients = if (-not [string]::IsNullOrWhiteSpace($AiClients)) {
        @($AiClients -split '[,; ]+' | Where-Object { $_ } | ForEach-Object {
            $name = $_
            $match = $script:AllAiClients | Where-Object { $_ -ieq $name } | Select-Object -First 1
            if (-not $match) { throw "Unknown AI app: $name. Use ClaudeDesktop, ClaudeCode or Codex." }
            $match
        } | Select-Object -Unique)
    }
    elseif ($saved -and $saved.PSObject.Properties['ai_clients']) { @($saved.ai_clients | Where-Object { $script:AllAiClients -contains $_ }) }
    else { @($script:AllAiClients) }
    $chosenProduct = if ($ProductGiven) { $Product } elseif ($saved -and $saved.PSObject.Properties['product'] -and $saved.product -in 'All', 'AutoCAD', 'Revit') { [string]$saved.product } else { 'All' }
    $withSkills = if ($Skills) { $Skills -eq 'On' } elseif ($saved -and $saved.PSObject.Properties['skills']) { [bool]$saved.skills } else { $true }
    [pscustomobject]@{ AiClients = @($clients); Product = $chosenProduct; Skills = $withSkills }
}

function Save-InstallChoices {
    param($Choices, [string]$Path = $installChoicesPath)
    New-Item -ItemType Directory -Path (Split-Path -Parent $Path) -Force | Out-Null
    @{ ai_clients = @($Choices.AiClients); product = $Choices.Product; skills = [bool]$Choices.Skills; saved_utc = [DateTime]::UtcNow.ToString('o') } |
        ConvertTo-Json | Set-Content -LiteralPath $Path -Encoding UTF8
}

function Write-InstallResult {
    param([string]$Step, [ValidateSet('ok', 'skipped', 'failed')][string]$Status, [string]$Detail = '')
    Write-Host ("[RESULT] {0}={1} {2}" -f $Step, $Status, $Detail).TrimEnd()
}

function Get-Sha256Hex {
    param([string]$Path)

    $stream = [IO.File]::OpenRead($Path)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try {
        ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-', '')
    }
    finally {
        $algorithm.Dispose()
        $stream.Dispose()
    }
}

function ConvertTo-ConnectorVersionInfo {
    param([string]$Version)

    $normalized = ([string]$Version).Trim().TrimStart([char]0xFEFF)
    if ($normalized.StartsWith('v', [StringComparison]::OrdinalIgnoreCase)) {
        $normalized = $normalized.Substring(1)
    }
    $match = [regex]::Match($normalized, '^(?<major>\d+)\.(?<minor>\d+)\.(?<patch>\d+)(?:-(?<prerelease>[A-Za-z0-9.-]+))?$')
    if (-not $match.Success) {
        throw "Invalid connector version: $Version"
    }

    [pscustomobject]@{
        Normalized = $normalized
        Major = [System.Numerics.BigInteger]::Parse($match.Groups['major'].Value)
        Minor = [System.Numerics.BigInteger]::Parse($match.Groups['minor'].Value)
        Patch = [System.Numerics.BigInteger]::Parse($match.Groups['patch'].Value)
        PreRelease = $match.Groups['prerelease'].Value
    }
}

function Compare-ConnectorVersion {
    param(
        [string]$Left,
        [string]$Right
    )

    $leftVersion = ConvertTo-ConnectorVersionInfo $Left
    $rightVersion = ConvertTo-ConnectorVersionInfo $Right
    foreach ($property in @('Major', 'Minor', 'Patch')) {
        $comparison = $leftVersion.$property.CompareTo($rightVersion.$property)
        if ($comparison -ne 0) { return [Math]::Sign($comparison) }
    }

    if ([string]::IsNullOrWhiteSpace($leftVersion.PreRelease) -and [string]::IsNullOrWhiteSpace($rightVersion.PreRelease)) { return 0 }
    if ([string]::IsNullOrWhiteSpace($leftVersion.PreRelease)) { return 1 }
    if ([string]::IsNullOrWhiteSpace($rightVersion.PreRelease)) { return -1 }

    $leftParts = @($leftVersion.PreRelease.Split('.'))
    $rightParts = @($rightVersion.PreRelease.Split('.'))
    $count = [Math]::Max($leftParts.Count, $rightParts.Count)
    for ($index = 0; $index -lt $count; $index++) {
        if ($index -ge $leftParts.Count) { return -1 }
        if ($index -ge $rightParts.Count) { return 1 }
        $leftPart = $leftParts[$index]
        $rightPart = $rightParts[$index]
        $leftNumeric = $leftPart -cmatch '^\d+$'
        $rightNumeric = $rightPart -cmatch '^\d+$'
        if ($leftNumeric -and $rightNumeric) {
            $comparison = ([System.Numerics.BigInteger]::Parse($leftPart)).CompareTo([System.Numerics.BigInteger]::Parse($rightPart))
        }
        elseif ($leftNumeric) { $comparison = -1 }
        elseif ($rightNumeric) { $comparison = 1 }
        else { $comparison = [StringComparer]::Ordinal.Compare($leftPart, $rightPart) }
        if ($comparison -ne 0) { return [Math]::Sign($comparison) }
    }
    0
}

function Get-RequiredCommand {
    param([string]$Name)

    $command = Get-OptionalCommand $Name
    if (-not $command) {
        throw "$Name is not installed or is not available in PATH."
    }
    $command
}

function Get-OptionalCommand {
    param([string]$Name)

    $command = Get-Command $Name -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($command) { return $command.Source }
    if ($Name -eq 'git') {
        $candidates = @(
            (Join-Path $env:ProgramFiles 'Git\cmd\git.exe'),
            (Join-Path $env:ProgramFiles 'Git\cmd\git.cmd'),
            (Join-Path $env:LOCALAPPDATA 'Programs\Git\cmd\git.exe'),
            (Join-Path $env:LOCALAPPDATA 'Programs\Git\cmd\git.cmd')
        )
        if (${env:ProgramFiles(x86)}) {
            $candidates += @(
                (Join-Path ${env:ProgramFiles(x86)} 'Git\cmd\git.exe'),
                (Join-Path ${env:ProgramFiles(x86)} 'Git\cmd\git.cmd')
            )
        }
        foreach ($candidate in $candidates) {
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
        }
    }
    if ($Name -eq 'codex') {
        $desktopBin = Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\bin'
        $candidates = @(
            (Join-Path $HOME '.local\bin\codex.exe'),
            (Join-Path $env:APPDATA 'npm\codex.cmd')
        )
        if (Test-Path -LiteralPath $desktopBin) {
            $candidates += @(Get-ChildItem -LiteralPath $desktopBin -Filter codex.exe -Recurse -File |
                Sort-Object LastWriteTime -Descending | Select-Object -ExpandProperty FullName)
        }
        foreach ($candidate in $candidates) {
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
        }
    }
    if ($Name -eq 'claude') {
        $candidates = @(
            (Join-Path $HOME '.local\bin\claude.exe'),
            (Join-Path $env:APPDATA 'npm\claude.cmd'),
            (Join-Path $env:LOCALAPPDATA 'Programs\Claude Code\claude.exe')
        )
        foreach ($candidate in $candidates) {
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
        }
    }
    $null
}

function Invoke-External {
    param(
        [string]$FilePath,
        [string[]]$Arguments,
        [switch]$AllowFailure,
        # For probes whose "not found" answer is expected; the caller reads the output itself.
        [switch]$Quiet
    )

    $previousErrorPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $output = & $FilePath @Arguments 2>&1
        $exitCode = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $previousErrorPreference
    }
    if ($output -and -not $Quiet) {
        $output | ForEach-Object { Write-Host $_ }
    }
    if (-not $AllowFailure -and $exitCode -ne 0) {
        $details = ($output | ForEach-Object { $_.ToString() }) -join "`r`n"
        if ([string]::IsNullOrWhiteSpace($details)) { $details = 'The command returned no diagnostic output.' }
        $operation = (@($Arguments | Select-Object -First 2) -join ' ')
        throw "$FilePath [$operation] failed with exit code $exitCode.`r`n$details"
    }
    [pscustomobject]@{ ExitCode = $exitCode; Output = @($output) }
}

function Install-GitForWindows {
    $git = Get-OptionalCommand 'git'
    if ($git) { return $git }

    $winget = Get-OptionalCommand 'winget'
    if (-not $winget) {
        throw 'Git is required for optional team knowledge submission, and Windows Package Manager was not found. Install Git for Windows from https://git-scm.com/download/win, then reopen the connector.'
    }

    Write-Step 'Installing Git for Windows for optional team knowledge submission...'
    $installed = Invoke-External $winget @(
        'install', '--id', 'Git.Git', '--exact', '--source', 'winget', '--silent',
        '--accept-package-agreements', '--accept-source-agreements'
    ) -AllowFailure

    $git = Get-OptionalCommand 'git'
    if (-not $git) {
        $details = ($installed.Output | ForEach-Object { $_.ToString() }) -join "`r`n"
        throw "Git installation did not finish. Install Git for Windows and reopen the connector.`r`n$details"
    }
    Write-Step 'Git for Windows is installed.'
    $git
}

function Get-PrivateRepositoryGit {
    param([switch]$AllowInstall)

    $git = Get-OptionalCommand 'git'
    if (-not $git -and $AllowInstall) {
        $git = Install-GitForWindows
    }
    if (-not $git) {
        throw 'Git is required only for optional team knowledge submission. Allow the connector to install Git or install Git for Windows, then retry.'
    }

    Write-Step 'Checking access to the private GitHub repository...'
    Write-Step 'If GitHub opens, sign in with an account that can access EhabHassan007/Autodesk-MCP.'
    $oldInteractive = $env:GCM_INTERACTIVE
    $oldProvider = $env:GCM_PROVIDER
    $oldModes = $env:GCM_GITHUB_AUTHMODES
    try {
        $env:GCM_INTERACTIVE = 'always'
        $env:GCM_PROVIDER = 'github'
        $env:GCM_GITHUB_AUTHMODES = 'browser,device'
        $access = Invoke-External $git @('ls-remote', $RepositoryUrl, 'refs/heads/main') -AllowFailure
    }
    finally {
        if ($null -eq $oldInteractive) { Remove-Item Env:GCM_INTERACTIVE -ErrorAction SilentlyContinue } else { $env:GCM_INTERACTIVE = $oldInteractive }
        if ($null -eq $oldProvider) { Remove-Item Env:GCM_PROVIDER -ErrorAction SilentlyContinue } else { $env:GCM_PROVIDER = $oldProvider }
        if ($null -eq $oldModes) { Remove-Item Env:GCM_GITHUB_AUTHMODES -ErrorAction SilentlyContinue } else { $env:GCM_GITHUB_AUTHMODES = $oldModes }
    }
    if ($access.ExitCode -ne 0) {
        $details = ($access.Output | ForEach-Object { $_.ToString() }) -join "`r`n"
        throw "GitHub sign-in or private repository access failed. Sign in as an authorized account and retry.`r`n$details"
    }
    $line = @($access.Output | ForEach-Object { $_.ToString().Trim() } |
        Where-Object { $_ -match '^[0-9a-fA-F]{40}\s+refs/heads/main$' }) | Select-Object -First 1
    if (-not $line) {
        throw 'GitHub authentication succeeded, but the approved main branch was not returned.'
    }
    Write-Step 'Private GitHub repository access passed.'
    $git
}

function Read-UpdateState {
    if (-not (Test-Path -LiteralPath $updateStatePath -PathType Leaf)) {
        return [pscustomobject]@{
            repository = $RepositoryUrl
            release_manifest = $ReleaseManifestUrl
            installed_version = ''
            installed_sha256 = ''
            installed_commit = ''
            # Automatic updates are on by default; only an explicit choice in Settings turns them off.
            notifications_enabled = $true
            notifications_user_disabled = $false
            last_checked_utc = ''
        }
    }
    try {
        Get-Content -LiteralPath $updateStatePath -Raw | ConvertFrom-Json
    }
    catch {
        throw "The connector update state is damaged: $updateStatePath"
    }
}

function Set-StateProperty {
    param(
        [object]$State,
        [string]$Name,
        [object]$Value
    )

    if ($State.PSObject.Properties.Name -contains $Name) {
        $State.$Name = $Value
    }
    else {
        $State | Add-Member -NotePropertyName $Name -NotePropertyValue $Value
    }
}

function Write-UpdateState {
    param([object]$State)

    New-Item -ItemType Directory -Path $updateStateDirectory -Force | Out-Null
    $State | ConvertTo-Json | Set-Content -LiteralPath $updateStatePath -Encoding UTF8
}

function Get-PublicReleaseManifest {
    Write-Step 'Checking the Smart Connector release channel...'
    try { $manifestUri = [Uri]$ReleaseManifestUrl }
    catch { throw "The release manifest address is invalid: $ReleaseManifestUrl" }
    if ($manifestUri.Scheme -ne 'https') {
        throw 'The release manifest must use HTTPS.'
    }

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $response = Invoke-WebRequest -Uri $manifestUri.AbsoluteUri -UseBasicParsing
        $content = if ($response.Content -is [byte[]]) {
            [Text.Encoding]::UTF8.GetString([byte[]]$response.Content)
        }
        else { [string]$response.Content }
        $manifest = $content.TrimStart([char]0xFEFF) | ConvertFrom-Json
    }
    catch {
        throw "Could not read the public release channel. $($_.Exception.Message)"
    }

    try { $version = (ConvertTo-ConnectorVersionInfo ([string]$manifest.version)).Normalized }
    catch { throw 'The public release manifest contains an invalid version.' }
    $downloadUrl = ([string]$manifest.download_url).Trim()
    $sha256 = ([string]$manifest.sha256).Trim().ToUpperInvariant()
    if ($sha256 -cnotmatch '^[0-9A-F]{64}$') {
        throw 'The public release manifest contains an invalid SHA-256 checksum.'
    }
    try { $downloadUri = [Uri]$downloadUrl }
    catch { throw 'The public release manifest contains an invalid download address.' }
    if ($downloadUri.Scheme -ne 'https') {
        throw 'The public release download must use HTTPS.'
    }

    [pscustomobject]@{
        Version = $version
        DownloadUrl = $downloadUri.AbsoluteUri
        Sha256 = $sha256
    }
}

function Get-InstalledVersion {
    $versionPath = Join-Path $RepositoryPath 'VERSION'
    if (Test-Path -LiteralPath $versionPath -PathType Leaf) {
        return (Get-Content -LiteralPath $versionPath -Raw).Trim()
    }
    ''
}

function Set-InstalledRelease {
    param(
        [string]$Version,
        [string]$Sha256 = ''
    )

    $state = Read-UpdateState
    Set-StateProperty $state 'repository' $RepositoryUrl
    Set-StateProperty $state 'release_manifest' $ReleaseManifestUrl
    Set-StateProperty $state 'installed_version' $Version
    Set-StateProperty $state 'installed_sha256' $Sha256
    Set-StateProperty $state 'last_checked_utc' ([DateTime]::UtcNow.ToString('o'))
    Write-UpdateState $state
}

function Test-ApprovedUpdate {
    $release = Get-PublicReleaseManifest
    $state = Read-UpdateState
    $installedVersion = Get-InstalledVersion
    Set-StateProperty $state 'repository' $RepositoryUrl
    Set-StateProperty $state 'release_manifest' $ReleaseManifestUrl
    Set-StateProperty $state 'installed_version' $installedVersion
    Set-StateProperty $state 'last_checked_utc' ([DateTime]::UtcNow.ToString('o'))
    # The Smart Connector app reads this to say "version X is ready" without going online again.
    $newer = -not [string]::IsNullOrWhiteSpace($installedVersion) -and (Compare-ConnectorVersion -Left $release.Version -Right $installedVersion) -gt 0
    Set-StateProperty $state 'available_version' $(if ($newer) { $release.Version } else { '' })
    Write-UpdateState $state

    if ([string]::IsNullOrWhiteSpace($installedVersion)) {
        Write-Output ("[{0}] [UPDATE_STATUS_UNKNOWN] Press Install / Repair to complete this installation." -f (Get-Date -Format 'HH:mm:ss'))
        return
    }
    $comparison = Compare-ConnectorVersion -Left $release.Version -Right $installedVersion
    if ($comparison -gt 0) {
        Write-Output ("[{0}] [UPDATE_AVAILABLE] Version {1} is available." -f (Get-Date -Format 'HH:mm:ss'), $release.Version)
        return
    }
    if ($comparison -lt 0) {
        Write-Output ("[{0}] [UP_TO_DATE] Installed version {1} is newer than public version {2}; no downgrade will be performed." -f (Get-Date -Format 'HH:mm:ss'), $installedVersion, $release.Version)
        return
    }
    Write-Output ("[{0}] [UP_TO_DATE] Smart Connector {1} and approved skills are up to date." -f (Get-Date -Format 'HH:mm:ss'), $installedVersion)
}

# Smart Connector runs nothing in the background. This removes the scheduled tasks, the notification-area agent
# and the Claude remote gateway that earlier versions set up (scripts\retire-background-tasks.ps1).
function Remove-BackgroundTasks {
    param([string]$Root, [switch]$StopAgent)
    $retire = Join-Path $Root 'scripts\retire-background-tasks.ps1'
    if (-not (Test-Path -LiteralPath $retire -PathType Leaf)) { return }
    try { & $retire -StopAgent:$StopAgent | ForEach-Object { Write-Step $_ } }
    catch { Write-Step ('Earlier background tasks could not all be removed: {0}' -f $_.Exception.Message) }
}

function Remove-LegacyUpdateTask {
    # Before the connector agent, a separate scheduled task installed updates at 9:00.
    if (Get-ScheduledTask -TaskName $updateTaskName -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $updateTaskName -Confirm:$false
    }
}

# Update checks run when Revit, AutoCAD or the Smart Connector app opens (at most once a day); they read this
# switch. Nothing here goes online.
function Enable-UpdateNotifications {
    $state = Read-UpdateState
    Set-StateProperty $state 'repository' $RepositoryUrl
    Set-StateProperty $state 'release_manifest' $ReleaseManifestUrl
    Set-StateProperty $state 'installed_version' (Get-InstalledVersion)
    Set-StateProperty $state 'notifications_enabled' $true
    Set-StateProperty $state 'notifications_user_disabled' $false
    Write-UpdateState $state
    Remove-LegacyUpdateTask
    Write-Step 'Update checks are on: Revit, AutoCAD and Smart Connector look for a new version once a day when they open, and ask before installing.'
}

function Disable-UpdateNotifications {
    Remove-LegacyUpdateTask
    $state = Read-UpdateState
    Set-StateProperty $state 'notifications_enabled' $false
    Set-StateProperty $state 'notifications_user_disabled' $true
    Write-UpdateState $state
    Write-Step 'Update checks are off. Use Check Updates to look for a new version.'
}

function Get-RunningAutodeskApps {
    @(Get-Process -Name 'Revit', 'acad' -ErrorAction SilentlyContinue | ForEach-Object { if ($_.ProcessName -eq 'acad') { 'AutoCAD' } else { 'Revit' } } | Sort-Object -Unique)
}

# A running SmartConnector.exe locks its file, unlike the PowerShell bridges. Before the install folder is replaced,
# stop only this install's own connector processes; the AI apps start it again when they next open.
function Stop-SmartConnectorServers {
    $folder = [IO.Path]::GetFullPath($RepositoryPath).TrimEnd('\') + '\'
    foreach ($process in @(Get-Process -Name 'SmartConnector' -ErrorAction SilentlyContinue)) {
        try {
            if ($process.Path -and $process.Path.StartsWith($folder, [StringComparison]::OrdinalIgnoreCase)) {
                Stop-Process -Id $process.Id -Force -ErrorAction Stop
                $null = $process.WaitForExit(5000)
            }
        }
        catch { Write-Step "Could not stop Smart Connector process $($process.Id): $($_.Exception.Message)" }
    }
}

function Get-GitHubArchiveUrl {
    param(
        [string]$Url,
        [string]$Branch = 'main'
    )

    try { $uri = [Uri]$Url }
    catch { throw "The repository address is not valid: $Url" }
    if ($uri.Host -ne 'github.com') {
        throw 'Direct download without Git currently supports github.com repositories only.'
    }

    $parts = @($uri.AbsolutePath.Trim('/') -split '/')
    if ($parts.Count -lt 2) {
        throw "The GitHub repository address is incomplete: $Url"
    }
    $owner = $parts[0]
    $repository = $parts[1] -replace '\.git$', ''
    if ([string]::IsNullOrWhiteSpace($owner) -or [string]::IsNullOrWhiteSpace($repository)) {
        throw "The GitHub repository address is incomplete: $Url"
    }
    "https://github.com/$owner/$repository/archive/refs/heads/$([Uri]::EscapeDataString($Branch)).zip"
}

function Assert-SafeRepositoryPath {
    $fullPath = [IO.Path]::GetFullPath($RepositoryPath).TrimEnd('\')
    $driveRoot = [IO.Path]::GetPathRoot($fullPath).TrimEnd('\')
    if ($fullPath -eq $driveRoot -or $fullPath -eq [IO.Path]::GetFullPath($HOME).TrimEnd('\')) {
        throw "The installation folder is not safe to replace: $fullPath"
    }
}

function Install-RepositoryArchive {
    Assert-SafeRepositoryPath
    $archiveUrl = Get-GitHubArchiveUrl -Url $RepositoryUrl
    $temporaryRoot = Join-Path ([IO.Path]::GetTempPath()) ("bim-cad-mcp-{0}" -f [Guid]::NewGuid().ToString('N'))
    $archivePath = Join-Path $temporaryRoot 'repository.zip'
    $expandedPath = Join-Path $temporaryRoot 'expanded'
    $backupPath = "$RepositoryPath.previous-$PID"
    $repositoryMoved = $false

    New-Item -ItemType Directory -Path $expandedPath -Force | Out-Null
    try {
        Write-Step 'Git is not installed. Downloading the current setup and skills directly from GitHub...'
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $archiveUrl -OutFile $archivePath -UseBasicParsing
        if (-not (Test-Path -LiteralPath $archivePath -PathType Leaf) -or (Get-Item -LiteralPath $archivePath).Length -eq 0) {
            throw 'GitHub returned an empty download.'
        }
        Expand-Archive -LiteralPath $archivePath -DestinationPath $expandedPath -Force

        $downloadedRoot = Get-ChildItem -LiteralPath $expandedPath -Directory |
            Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName '.agents\skills') -PathType Container } |
            Select-Object -First 1
        if (-not $downloadedRoot) {
            throw 'The GitHub download does not contain the BIM-CAD MCP skill library.'
        }

        $parent = Split-Path -Parent ([IO.Path]::GetFullPath($RepositoryPath))
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
        if (Test-Path -LiteralPath $backupPath) {
            Remove-Item -LiteralPath $backupPath -Recurse -Force
        }
        if (Test-Path -LiteralPath $RepositoryPath) {
            Stop-SmartConnectorServers
            Move-Item -LiteralPath $RepositoryPath -Destination $backupPath
            $repositoryMoved = $true
        }

        try {
            Move-Item -LiteralPath $downloadedRoot.FullName -Destination $RepositoryPath
            foreach ($name in @('skill-review', 'team-candidates', 'team-collection', 'backups')) {
                $saved = Join-Path $backupPath $name
                $destination = Join-Path $RepositoryPath $name
                if ($repositoryMoved -and (Test-Path -LiteralPath $saved) -and -not (Test-Path -LiteralPath $destination)) {
                    Move-Item -LiteralPath $saved -Destination $destination
                }
            }
            [ordered]@{
                repository = $RepositoryUrl
                branch = 'main'
                downloaded_utc = [DateTime]::UtcNow.ToString('o')
                method = 'github-zip'
            } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $RepositoryPath '.bim-cad-source.json') -Encoding UTF8
        }
        catch {
            if (Test-Path -LiteralPath $RepositoryPath) {
                Remove-Item -LiteralPath $RepositoryPath -Recurse -Force
            }
            if ($repositoryMoved -and (Test-Path -LiteralPath $backupPath)) {
                Move-Item -LiteralPath $backupPath -Destination $RepositoryPath
            }
            throw
        }

        if ($repositoryMoved -and (Test-Path -LiteralPath $backupPath)) {
            Remove-Item -LiteralPath $backupPath -Recurse -Force
        }
    }
    catch {
        throw "Could not download the repository from GitHub. $($_.Exception.Message)"
    }
    finally {
        if (Test-Path -LiteralPath $temporaryRoot) {
            Remove-Item -LiteralPath $temporaryRoot -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

function Test-GitRepository {
    param(
        [string]$Git,
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { return $false }
    $result = Invoke-External $Git @('-C', $Path, 'rev-parse', '--is-inside-work-tree') -AllowFailure
    $result.ExitCode -eq 0 -and (@($result.Output | ForEach-Object { $_.ToString().Trim() }) -contains 'true')
}

function Sync-ApprovedGitRepository {
    param([string]$Git)

    Write-Step 'Downloading the newest approved setup and skills from GitHub...'
    $configured = Invoke-External $Git @('-C', $RepositoryPath, 'remote', 'set-url', 'origin', $RepositoryUrl)
    $null = $configured
    $fetched = Invoke-External $Git @('-C', $RepositoryPath, 'fetch', '--prune', 'origin', 'main')
    $null = $fetched

    # Install / Repair can copy a packaged beta over an older installed Git checkout.
    # Treat this folder as a managed installation and restore its tracked files from
    # the approved main branch. Untracked review packages and team candidates remain.
    Write-Step 'Refreshing packaged connector files from the approved update channel...'
    $reset = Invoke-External $Git @('-C', $RepositoryPath, 'reset', '--hard', 'origin/main')
    $null = $reset
    $checkedOut = Invoke-External $Git @('-C', $RepositoryPath, 'checkout', '-B', 'main', 'origin/main')
    $null = $checkedOut
}

function Install-RepositoryClone {
    param([string]$Git)

    Assert-SafeRepositoryPath
    $temporaryRoot = Join-Path ([IO.Path]::GetTempPath()) ("autodesk-mcp-clone-{0}" -f [Guid]::NewGuid().ToString('N'))
    $downloadedRoot = Join-Path $temporaryRoot 'repository'
    $backupPath = "$RepositoryPath.previous-$PID"
    $repositoryMoved = $false

    New-Item -ItemType Directory -Path $temporaryRoot -Force | Out-Null
    try {
        Write-Step 'Downloading the approved main version through Git...'
        $cloned = Invoke-External $Git @('clone', '--depth', '1', '--branch', 'main', '--single-branch', $RepositoryUrl, $downloadedRoot)
        $null = $cloned
        if (-not (Test-Path -LiteralPath (Join-Path $downloadedRoot '.agents\skills') -PathType Container)) {
            throw 'The downloaded repository does not contain .agents\skills.'
        }

        if (Test-Path -LiteralPath $backupPath) {
            Remove-Item -LiteralPath $backupPath -Recurse -Force
        }
        if (Test-Path -LiteralPath $RepositoryPath) {
            Stop-SmartConnectorServers
            Move-Item -LiteralPath $RepositoryPath -Destination $backupPath
            $repositoryMoved = $true
        }
        try {
            Move-Item -LiteralPath $downloadedRoot -Destination $RepositoryPath
            foreach ($name in @('skill-review', 'team-candidates', 'team-collection', 'backups')) {
                $saved = Join-Path $backupPath $name
                $destination = Join-Path $RepositoryPath $name
                if ($repositoryMoved -and (Test-Path -LiteralPath $saved) -and -not (Test-Path -LiteralPath $destination)) {
                    Move-Item -LiteralPath $saved -Destination $destination
                }
            }
        }
        catch {
            if (Test-Path -LiteralPath $RepositoryPath) {
                Remove-Item -LiteralPath $RepositoryPath -Recurse -Force
            }
            if ($repositoryMoved -and (Test-Path -LiteralPath $backupPath)) {
                Move-Item -LiteralPath $backupPath -Destination $RepositoryPath
            }
            throw
        }
        if ($repositoryMoved -and (Test-Path -LiteralPath $backupPath)) {
            Remove-Item -LiteralPath $backupPath -Recurse -Force
        }
    }
    finally {
        if (Test-Path -LiteralPath $temporaryRoot) {
            Remove-Item -LiteralPath $temporaryRoot -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

function Install-PublicRelease {
    param([object]$Release)

    Assert-SafeRepositoryPath
    if (-not $Release) { $Release = Get-PublicReleaseManifest }

    $temporaryRoot = Join-Path ([IO.Path]::GetTempPath()) ("autodesk-mcp-release-{0}" -f [Guid]::NewGuid().ToString('N'))
    $releaseArchive = Join-Path $temporaryRoot 'release.zip'
    $outerRoot = Join-Path $temporaryRoot 'outer'
    $payloadRoot = Join-Path $temporaryRoot 'payload'
    $backupPath = "$RepositoryPath.previous-$PID"
    $repositoryMoved = $false

    New-Item -ItemType Directory -Path $outerRoot, $payloadRoot -Force | Out-Null
    try {
        Write-Step ("Downloading approved public release {0}..." -f $Release.Version)
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $null = Invoke-WebRequest -Uri $Release.DownloadUrl -OutFile $releaseArchive -UseBasicParsing
        if (-not (Test-Path -LiteralPath $releaseArchive -PathType Leaf) -or (Get-Item -LiteralPath $releaseArchive).Length -eq 0) {
            throw 'The public release download is empty.'
        }

        $actualHash = (Get-Sha256Hex -Path $releaseArchive).ToUpperInvariant()
        if (-not $actualHash.Equals($Release.Sha256, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Release checksum verification failed. Expected $($Release.Sha256), received $actualHash."
        }
        Write-Step 'Release checksum verification passed.'

        Expand-Archive -LiteralPath $releaseArchive -DestinationPath $outerRoot -Force
        $payloadArchive = Get-ChildItem -LiteralPath $outerRoot -Filter 'Autodesk-MCP-Payload.zip' -File -Recurse | Select-Object -First 1
        if (-not $payloadArchive) {
            throw 'The public release does not contain Autodesk-MCP-Payload.zip.'
        }
        Expand-Archive -LiteralPath $payloadArchive.FullName -DestinationPath $payloadRoot -Force
        $downloadedRoot = Get-ChildItem -LiteralPath $payloadRoot -Directory -Recurse |
            Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName '.agents\skills') -PathType Container } |
            Select-Object -First 1
        if (-not $downloadedRoot) {
            throw 'The public release payload does not contain the approved skill library.'
        }
        $payloadVersion = (Get-Content -LiteralPath (Join-Path $downloadedRoot.FullName 'VERSION') -Raw).Trim()
        if (-not $payloadVersion.Equals($Release.Version, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Release version verification failed. Manifest says $($Release.Version), payload says $payloadVersion."
        }

        $parent = Split-Path -Parent ([IO.Path]::GetFullPath($RepositoryPath))
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
        if (Test-Path -LiteralPath $backupPath) {
            Remove-Item -LiteralPath $backupPath -Recurse -Force
        }
        if (Test-Path -LiteralPath $RepositoryPath) {
            Stop-SmartConnectorServers
            Move-Item -LiteralPath $RepositoryPath -Destination $backupPath
            $repositoryMoved = $true
        }

        try {
            Move-Item -LiteralPath $downloadedRoot.FullName -Destination $RepositoryPath
            foreach ($name in @('skill-review', 'team-candidates', 'team-collection', 'backups')) {
                $saved = Join-Path $backupPath $name
                $destination = Join-Path $RepositoryPath $name
                if ($repositoryMoved -and (Test-Path -LiteralPath $saved) -and -not (Test-Path -LiteralPath $destination)) {
                    Move-Item -LiteralPath $saved -Destination $destination
                }
            }
            [ordered]@{
                release_manifest = $ReleaseManifestUrl
                version = $Release.Version
                sha256 = $Release.Sha256
                downloaded_utc = [DateTime]::UtcNow.ToString('o')
                method = 'public-release'
            } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $RepositoryPath '.bim-cad-source.json') -Encoding UTF8
        }
        catch {
            if (Test-Path -LiteralPath $RepositoryPath) {
                Remove-Item -LiteralPath $RepositoryPath -Recurse -Force
            }
            if ($repositoryMoved -and (Test-Path -LiteralPath $backupPath)) {
                Move-Item -LiteralPath $backupPath -Destination $RepositoryPath
            }
            throw
        }

        if ($repositoryMoved -and (Test-Path -LiteralPath $backupPath)) {
            Remove-Item -LiteralPath $backupPath -Recurse -Force
        }
        Set-InstalledRelease -Version $Release.Version -Sha256 $Release.Sha256
        (Resolve-Path -LiteralPath $RepositoryPath).Path
    }
    finally {
        if (Test-Path -LiteralPath $temporaryRoot) {
            Remove-Item -LiteralPath $temporaryRoot -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

function Get-Repository {
    # A downloaded package already contains everything needed for installation.
    # Copy it to a permanent location without requiring private GitHub access.
    $packageRoot = Split-Path -Parent $PSScriptRoot
    if ($Action -eq 'Install' -and -not $SkipRepositoryUpdate -and
        (Test-Path -LiteralPath (Join-Path $packageRoot '.agents\skills') -PathType Container)) {
        $source = [IO.Path]::GetFullPath($packageRoot).TrimEnd('\')
        $destination = [IO.Path]::GetFullPath($RepositoryPath).TrimEnd('\')
        if ($source -ne $destination) {
            if ($source.StartsWith($destination + '\', [StringComparison]::OrdinalIgnoreCase) -or
                $destination.StartsWith($source + '\', [StringComparison]::OrdinalIgnoreCase)) {
                throw 'The installation folder cannot be inside or contain the downloaded package.'
            }
            Write-Step 'Installing the downloaded package to a permanent local folder...'
            New-Item -ItemType Directory -Path $destination -Force | Out-Null
            # The shipped skill library is replaced, not merged: an older install keeps skills flat, and merging
            # would leave every skill twice next to the new category folders. Approved team skills live elsewhere.
            $installedSkills = Join-Path $destination '.agents\skills'
            if (Test-Path -LiteralPath $installedSkills) { Remove-Item -LiteralPath $installedSkills -Recurse -Force }
            Stop-SmartConnectorServers
            foreach ($entry in @('installer','scripts','src','assets','bin','.agents','README.md','SKILL-SUBMISSIONS.md','VERSION','TESTING.md')) {
                $item = Join-Path $source $entry
                if (Test-Path -LiteralPath $item) {
                    Copy-Item -LiteralPath $item -Destination $destination -Recurse -Force
                }
            }
            # The team join code stays in the downloaded installer only, even when joining was skipped.
            $copiedJoin = Join-Path $destination 'installer\team-join.json'
            if (Test-Path -LiteralPath $copiedJoin -PathType Leaf) { Remove-Item -LiteralPath $copiedJoin -Force }
        }
        Set-InstalledRelease -Version ((Get-Content -LiteralPath (Join-Path $destination 'VERSION') -Raw).Trim())
        return $destination
    }
    $manifest = Join-Path $RepositoryPath '.agents\skills'
    if ($SkipRepositoryUpdate) {
        if (-not (Test-Path -LiteralPath $manifest -PathType Container)) {
            throw "No valid BIM-CAD MCP repository exists at $RepositoryPath."
        }
        return (Resolve-Path -LiteralPath $RepositoryPath).Path
    }

    if ($Action -eq 'Install' -and (Test-Path -LiteralPath $manifest -PathType Container)) {
        Set-InstalledRelease -Version (Get-InstalledVersion)
        return (Resolve-Path -LiteralPath $RepositoryPath).Path
    }

    $script:UpdateDownloaded = $false
    $release = Get-PublicReleaseManifest
    if ($Action -eq 'Update') {
        $installedVersion = Get-InstalledVersion
        if (-not [string]::IsNullOrWhiteSpace($installedVersion)) {
            $comparison = Compare-ConnectorVersion -Left $release.Version -Right $installedVersion
            if ($comparison -le 0) {
                if ($comparison -lt 0) {
                    Write-Step ("Installed version {0} is newer than public version {1}; the update was skipped to prevent a downgrade." -f $installedVersion, $release.Version)
                }
                else {
                    Write-Step ("Smart Connector {0} is already up to date." -f $installedVersion)
                }
                return (Resolve-Path -LiteralPath $RepositoryPath).Path
            }
        }
    }
    $installedRoot = Install-PublicRelease -Release $release
    $script:UpdateDownloaded = $true
    return $installedRoot

    if (-not (Test-Path -LiteralPath $manifest -PathType Container)) {
        throw "The downloaded repository does not contain .agents\skills."
    }
    (Resolve-Path -LiteralPath $RepositoryPath).Path
}

function Install-Skills {
    param([string]$Root)

    $syncScript = Join-Path $Root 'scripts\sync-codex-skills.ps1'
    if (-not (Test-Path -LiteralPath $syncScript -PathType Leaf)) {
        throw "Skill installer is missing: $syncScript"
    }
    Write-Step 'Installing all saved skills for Codex...'
    $result = Invoke-External 'powershell.exe' @('-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', $syncScript, '-Action', 'Install')
    $null = $result

    $claudeSkills = Join-Path $HOME '.claude\skills'
    Write-Step 'Installing the same saved skills for Claude Code...'
    $result = Invoke-External 'powershell.exe' @('-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', $syncScript, '-Action', 'Install', '-Destination', $claudeSkills)
    $null = $result
}

function Test-OwnConnectorEntry {
    param([string]$Text)
    # Only entries that launch this connector's own bridges count as duplicates; another
    # tool's server with a similar name is left alone.
    $Text -match '(?i)BIM-CAD-MCP|SmartConnector\.exe|autodesk-bridge\.ps1|autocad-bridge\.ps1|revit-bridge\.ps1'
}

# How an AI app starts the connector: the compiled SmartConnector.exe when it is installed (bin\SmartConnector.exe),
# otherwise the PowerShell bridge. Returns the command and its arguments.
function Get-McpLaunch {
    param([string]$Bridge, [string[]]$BridgeArguments = @())
    if ($Bridge -like '*.exe') { return [pscustomobject]@{ Command = $Bridge; Arguments = @($BridgeArguments) } }
    [pscustomobject]@{ Command = 'powershell.exe'; Arguments = @('-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', $Bridge) + $BridgeArguments }
}

function Remove-LegacyMcpEntries {
    param([string]$Client, [string]$Command, [string[]]$LegacyNames, [string[]]$RemoveArguments = @())
    foreach ($legacy in $LegacyNames) {
        $existing = Invoke-External $Command @('mcp', 'get', $legacy) -AllowFailure -Quiet
        if ($existing.ExitCode -ne 0 -or -not (Test-OwnConnectorEntry ($existing.Output -join "`n"))) { continue }
        $removed = Invoke-External $Command (@('mcp', 'remove', $legacy) + $RemoveArguments) -AllowFailure
        if ($removed.ExitCode -eq 0) { Write-Step ("Removed the older duplicate {0} MCP entry '{1}'." -f $Client, $legacy) }
    }
}

function Register-McpServer {
    param(
        [string]$Name,
        [string]$Bridge,
        [string[]]$BridgeArguments = @(),
        [string[]]$LegacyNames = @()
    )

    $codex = Get-RequiredCommand 'codex'
    if (-not (Test-Path -LiteralPath $Bridge -PathType Leaf)) {
        throw "MCP bridge is missing: $Bridge"
    }

    $codexHome = if ([string]::IsNullOrWhiteSpace($env:CODEX_HOME)) { Join-Path $HOME '.codex' } else { $env:CODEX_HOME }
    $configPath = Join-Path $codexHome 'config.toml'
    $backupPath = Join-Path $codexHome ("config.toml.bim-cad-setup-{0}.bak" -f $PID)
    $hasBackup = $false
    if (Test-Path -LiteralPath $configPath -PathType Leaf) {
        Copy-Item -LiteralPath $configPath -Destination $backupPath -Force
        $hasBackup = $true
    }

    Write-Step ("Registering the {0} MCP server in Codex..." -f $Name)
    try {
        # Read-only verification avoids rewriting an already correct registration.
        $existing = Invoke-External $codex @('mcp', 'get', $Name, '--json') -AllowFailure
        if ($existing.ExitCode -eq 0) {
            try {
                $entry = ($existing.Output -join "`n") | ConvertFrom-Json
                $launch = Get-McpLaunch $Bridge $BridgeArguments
                $expectedArgs = $launch.Arguments
                if ($entry.enabled -ne $false -and $entry.transport.command -eq $launch.Command -and
                    (($entry.transport.args | ConvertTo-Json -Compress) -ceq ($expectedArgs | ConvertTo-Json -Compress))) {
                    Write-Step 'The Smart Connector registration in Codex is already correct.'
                    Remove-LegacyMcpEntries 'Codex' $codex $LegacyNames
                    return
                }
            }
            catch { Write-Step 'Existing Codex registration could not be compared; registering the requested command.' }
        }
        Remove-LegacyMcpEntries 'Codex' $codex $LegacyNames
        # mcp add replaces this named entry and leaves unrelated servers alone.
        $launch = Get-McpLaunch $Bridge $BridgeArguments
        $command = @('mcp', 'add', $Name, '--', $launch.Command) + $launch.Arguments
        $added = Invoke-External $codex $command
        $null = $added
        $verified = Invoke-External $codex @('mcp', 'get', $Name)
        $null = $verified
    }
    catch {
        if ($hasBackup) {
            Copy-Item -LiteralPath $backupPath -Destination $configPath -Force
        }
        throw
    }
    finally {
        if ($hasBackup -and (Test-Path -LiteralPath $backupPath)) {
            Remove-Item -LiteralPath $backupPath -Force
        }
    }
}

function Get-ClaudeDesktopInstallation {
    $candidatePaths = @(
        (Join-Path $env:LOCALAPPDATA 'AnthropicClaude\Claude.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Claude\Claude.exe'),
        (Join-Path $env:LOCALAPPDATA 'Claude\Claude.exe'),
        (Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\Claude.exe'),
        (Join-Path $env:ProgramFiles 'Claude\Claude.exe')
    )
    foreach ($candidate in $candidatePaths) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return [pscustomobject]@{ Installed=$true; Executable=$candidate; Source='file' }
        }
    }

    # AppX package enumeration may be blocked in restricted Windows sessions.
    # The package data directory is sufficient evidence that Claude Desktop is
    # installed, while its MCP config still belongs in roaming AppData.
    $packagesRoot = Join-Path $env:LOCALAPPDATA 'Packages'
    if (Test-Path -LiteralPath $packagesRoot -PathType Container) {
        $packageDirectory = Get-ChildItem -LiteralPath $packagesRoot -Directory -Filter '*Claude*' -ErrorAction SilentlyContinue |
            Select-Object -First 1
        if ($packageDirectory) {
            return [pscustomobject]@{ Installed=$true; Executable=''; Source='appx-directory' }
        }
    }

    $uninstallRoots = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
    )
    foreach ($root in $uninstallRoots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        $match = Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue |
            ForEach-Object { Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue } |
            Where-Object { [string]$_.DisplayName -match '^Claude(?: Desktop)?$' } |
            Select-Object -First 1
        if ($match) {
            $executable = ''
            $displayIcon = ([string]$match.DisplayIcon).Trim().Trim('"') -replace ',\d+$', ''
            if ($displayIcon -and (Test-Path -LiteralPath $displayIcon -PathType Leaf)) {
                $executable = $displayIcon
            }
            elseif ($match.InstallLocation) {
                $installedCandidate = Join-Path ([string]$match.InstallLocation) 'Claude.exe'
                if (Test-Path -LiteralPath $installedCandidate -PathType Leaf) {
                    $executable = $installedCandidate
                }
            }
            return [pscustomobject]@{ Installed=$true; Executable=$executable; Source='uninstall-registry' }
        }
    }

    try {
        $package = @(Get-AppxPackage -ErrorAction Stop | Where-Object {
            $_.Name -like '*Claude*' -or $_.PackageFamilyName -like '*Claude*'
        }) | Select-Object -First 1
        if ($package) {
            $executable = ''
            foreach ($relativePath in @('Claude.exe', 'app\Claude.exe')) {
                $candidate = Join-Path ([string]$package.InstallLocation) $relativePath
                if (Test-Path -LiteralPath $candidate -PathType Leaf) {
                    $executable = $candidate
                    break
                }
            }
            return [pscustomobject]@{ Installed=$true; Executable=$executable; Source='appx' }
        }
    }
    catch { }

    $null
}

function Test-ClaudeDesktopInstalled {
    $null -ne (Get-ClaudeDesktopInstallation)
}

function Get-ClaudeDesktopConfigPath {
    Join-Path (Join-Path $env:APPDATA 'Claude') 'claude_desktop_config.json'
}

function Get-ClaudeDesktopConfigPaths {
    $paths = @((Get-ClaudeDesktopConfigPath))
    $packagesRoot = Join-Path $env:LOCALAPPDATA 'Packages'
    if (Test-Path -LiteralPath $packagesRoot -PathType Container) {
        foreach ($package in @(Get-ChildItem -LiteralPath $packagesRoot -Directory -Filter '*Claude*' -ErrorAction SilentlyContinue)) {
            $paths += Join-Path $package.FullName 'LocalCache\Roaming\Claude\claude_desktop_config.json'
        }
    }
    $paths | Select-Object -Unique
}

function Get-ClaudeDesktopProcesses {
    @(
        Get-Process -Name 'Claude' -ErrorAction SilentlyContinue |
            Where-Object {
                $path = ''
                try { $path = [string]$_.Path } catch { }
                $_.MainWindowTitle -match 'Claude' -or
                    $path -match '(?i)\\(?:AnthropicClaude|Programs\\Claude|WindowsApps\\[^\\]*Claude|Claude)\\'
            }
    )
}

function Restart-ClaudeDesktopIfRunning {
    param(
        [object[]]$Processes,
        [object]$Installation
    )

    $running = @($Processes | Where-Object { $_ -and -not $_.HasExited })
    if ($running.Count -eq 0) { return }

    $launchPath = @(
        $running | ForEach-Object {
            try { if ($_.Path) { [string]$_.Path } } catch { }
        }
        if ($Installation -and $Installation.Executable) { [string]$Installation.Executable }
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1

    Write-Step 'Restarting Claude Desktop so it loads the Smart Connector registration...'
    foreach ($process in $running) {
        try { $null = $process.CloseMainWindow() } catch { }
    }
    Start-Sleep -Seconds 2
    foreach ($process in $running) {
        try {
            if (-not $process.HasExited) { Stop-Process -Id $process.Id -Force -ErrorAction Stop }
        }
        catch { Write-Step ("Claude Desktop process {0} could not be stopped automatically." -f $process.Id) }
    }

    try {
        if ($launchPath) {
            Start-Process -FilePath $launchPath | Out-Null
            Write-Step 'Claude Desktop restarted successfully.'
            return
        }
        $startApp = Get-StartApps -ErrorAction Stop |
            Where-Object { $_.Name -match '^Claude(?: Desktop)?$' -or $_.Name -match '^Anthropic Claude' } |
            Select-Object -First 1
        if ($startApp -and $startApp.AppID) {
            Start-Process -FilePath ("shell:AppsFolder\{0}" -f $startApp.AppID) | Out-Null
            Write-Step 'Claude Desktop restarted successfully.'
            return
        }
        Write-Step 'Claude Desktop was closed to reload the connector. Open it again from the Start menu.'
    }
    catch {
        Write-Step ("Claude Desktop was closed to reload the connector, but automatic relaunch failed: {0}" -f $_.Exception.Message)
    }
}

function Install-ClaudeDesktop {
    $installed = Get-ClaudeDesktopInstallation
    if ($installed) { return $installed }

    $winget = Get-OptionalCommand 'winget'
    if (-not $winget) {
        throw 'Claude Desktop is required for a local Revit connection, but Windows Package Manager was not found. Install Claude Desktop from https://claude.com/download, then run Install / Repair again.'
    }

    Write-Step 'Claude Desktop is not installed. Installing the official Anthropic package for the current Windows user...'
    $result = Invoke-External $winget @(
        'install', '--id', 'Anthropic.Claude', '--exact', '--source', 'winget', '--silent',
        '--accept-package-agreements', '--accept-source-agreements'
    ) -AllowFailure
    if ($result.ExitCode -ne 0) {
        $details = ($result.Output | ForEach-Object { $_.ToString() }) -join "`r`n"
        throw "Claude Desktop installation failed.`r`n$details"
    }

    for ($attempt = 0; $attempt -lt 20; $attempt++) {
        $installed = Get-ClaudeDesktopInstallation
        if ($installed) {
            Write-Step 'Claude Desktop is installed. The Smart Connector registration will now be added.'
            return $installed
        }
        Start-Sleep -Seconds 1
    }
    Write-Step 'Windows completed the Claude Desktop installation, but its executable is not enumerable yet. Continuing with the standard per-user MCP registration.'
    [pscustomobject]@{ Installed=$true; Executable=''; Source='winget' }
}

function Register-ClaudeCodeMcpServer {
    param(
        [string]$Name,
        [string]$Bridge,
        [string[]]$BridgeArguments = @(),
        [string[]]$LegacyNames = @()
    )

    $claude = Get-OptionalCommand 'claude'
    if (-not $claude) {
        Write-Step 'Claude Code was not detected, so its MCP registration was skipped.'
        return
    }
    if (-not (Test-Path -LiteralPath $Bridge -PathType Leaf)) {
        throw "MCP bridge is missing: $Bridge"
    }

    $configPath = Join-Path $HOME '.claude.json'
    $backupPath = "$configPath.autodesk-mcp-$PID.bak"
    $hadConfig = Test-Path -LiteralPath $configPath -PathType Leaf
    if ($hadConfig) { Copy-Item -LiteralPath $configPath -Destination $backupPath -Force }

    Write-Step ("Registering the {0} MCP server in Claude Code..." -f $Name)
    try {
        Remove-LegacyMcpEntries 'Claude Code' $claude $LegacyNames @('--scope', 'user')
        $existing = Invoke-External $claude @('mcp','get',$Name) -AllowFailure
        if ($existing.ExitCode -eq 0) {
            $removed = Invoke-External $claude @('mcp','remove',$Name,'--scope','user') -AllowFailure
            $null = $removed
        }

        $launch = Get-McpLaunch $Bridge $BridgeArguments
        $command = @('mcp', 'add', '--transport', 'stdio', '--scope', 'user', $Name, '--', $launch.Command) + $launch.Arguments
        $added = Invoke-External $claude $command
        $null = $added
        $verified = Invoke-External $claude @('mcp','get',$Name)
        $null = $verified
    }
    catch {
        if ($hadConfig) {
            Copy-Item -LiteralPath $backupPath -Destination $configPath -Force
        }
        elseif (Test-Path -LiteralPath $configPath) {
            Remove-Item -LiteralPath $configPath -Force
        }
        throw
    }
    finally {
        if (Test-Path -LiteralPath $backupPath) { Remove-Item -LiteralPath $backupPath -Force }
    }
}

function Register-ClaudeDesktopMcpServer {
    param(
        [string]$Name,
        [string]$Bridge,
        [string[]]$BridgeArguments = @(),
        [string[]]$LegacyNames = @(),
        [string]$ConfigPath = (Get-ClaudeDesktopConfigPath)
    )

    if (-not (Test-Path -LiteralPath $Bridge -PathType Leaf)) {
        throw "MCP bridge is missing: $Bridge"
    }

    $claudeDirectory = Split-Path -Parent $configPath
    $backupPath = "$configPath.autodesk-mcp-$PID.bak"
    $temporaryPath = "$configPath.autodesk-mcp-$PID.tmp"
    New-Item -ItemType Directory -Path $claudeDirectory -Force | Out-Null
    $hadConfig = Test-Path -LiteralPath $configPath -PathType Leaf
    if ($hadConfig) { Copy-Item -LiteralPath $configPath -Destination $backupPath -Force }

    Write-Step ("Registering the {0} local MCP server in Claude Desktop at {1}..." -f $Name, $configPath)
    try {
        $config = if ($hadConfig) {
            Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
        }
        else { [pscustomobject]@{} }

        if (-not $config.PSObject.Properties['mcpServers']) {
            $config | Add-Member -MemberType NoteProperty -Name 'mcpServers' -Value ([pscustomobject]@{})
        }
        elseif ($null -eq $config.mcpServers) {
            $config.mcpServers = [pscustomobject]@{}
        }

        # An old name is removed only when its entry starts this connector. Another tool that happens to use the same name
        # (a Python AutoCAD server called "AutoCAD MCP", a pyRevit server called "Revit Connector") is not ours to delete.
        foreach ($legacyName in $LegacyNames) {
            $existingEntry = $config.mcpServers.PSObject.Properties[$legacyName]
            if (-not $existingEntry) { continue }
            if (Test-OwnConnectorEntry ($existingEntry.Value | ConvertTo-Json -Depth 20 -Compress)) {
                $config.mcpServers.PSObject.Properties.Remove($legacyName)
                Write-Step ("Removed legacy Claude Desktop MCP registration: {0}." -f $legacyName)
            }
            else { Write-Step ("Kept the Claude Desktop entry '{0}': it does not start this connector." -f $legacyName) }
        }

        $launch = Get-McpLaunch $Bridge $BridgeArguments
        $entry = [pscustomobject][ordered]@{
            command = $launch.Command
            args = @($launch.Arguments)
        }
        if ($config.mcpServers.PSObject.Properties[$Name]) {
            $config.mcpServers.PSObject.Properties[$Name].Value = $entry
        }
        else {
            $config.mcpServers | Add-Member -MemberType NoteProperty -Name $Name -Value $entry
        }

        [IO.File]::WriteAllText($temporaryPath, ($config | ConvertTo-Json -Depth 30), (New-Object Text.UTF8Encoding($false)))
        $null = Get-Content -LiteralPath $temporaryPath -Raw | ConvertFrom-Json
        if ($hadConfig) {
            Copy-Item -LiteralPath $temporaryPath -Destination $configPath -Force
            Remove-Item -LiteralPath $temporaryPath -Force
        }
        else {
            Move-Item -LiteralPath $temporaryPath -Destination $configPath
        }
    }
    catch {
        if ($hadConfig -and (Test-Path -LiteralPath $backupPath)) {
            Copy-Item -LiteralPath $backupPath -Destination $configPath -Force
        }
        elseif (-not $hadConfig -and (Test-Path -LiteralPath $configPath)) {
            Remove-Item -LiteralPath $configPath -Force
        }
        throw "Claude Desktop registration failed. $($_.Exception.Message)"
    }
    finally {
        if (Test-Path -LiteralPath $temporaryPath) { Remove-Item -LiteralPath $temporaryPath -Force }
        if (Test-Path -LiteralPath $backupPath) { Remove-Item -LiteralPath $backupPath -Force }
    }
}

function Register-DetectedAiClients {
    param([string]$Root, [string[]]$Clients = $script:AllAiClients)

    $bridge = Join-Path $Root 'src\autodesk\autodesk-bridge.ps1'
    $arguments = @('-RevitVersion','2024')
    # The compiled connector replaces the PowerShell bridge wherever it is installed.
    $compiled = Join-Path $Root 'bin\SmartConnector.exe'
    if (Test-Path -LiteralPath $compiled -PathType Leaf) { $bridge = $compiled; $arguments = @('mcp') }
    $legacyNames = @('autocad','revit','AutoCAD MCP','Revit Connector','revit-mcp','autodesk')
    # Claude Desktop shows the key as the connector's name; the previous product name is retired.
    $claudeDesktopLegacyNames = @($legacyNames + 'autodesk' + 'Autodesk MCP Connector' + 'Smart Autodesk Connector')
    $detected = 0
    $registrationErrors = @()

    $claudeDesktopProcesses = @(Get-ClaudeDesktopProcesses)
    $claudeDesktopInstallation = Get-ClaudeDesktopInstallation

    Write-InstallPhase 'codex'
    if ($Clients -notcontains 'Codex') { Write-Step 'Codex was not selected in setup.'; Write-InstallResult 'codex' 'skipped' 'not selected' }
    elseif (Get-OptionalCommand 'codex') {
        try {
            Register-McpServer 'smart-connector' $bridge $arguments $legacyNames
            $detected++
            Write-InstallResult 'codex' 'ok'
        }
        catch {
            $registrationErrors += 'Codex: ' + $_.Exception.Message
            Write-Warning ('Codex registration failed; continuing with other clients: ' + $_.Exception.Message)
            Write-InstallResult 'codex' 'failed' 'see the setup log'
        }
    }
    else { Write-Step 'Codex was not detected, so its MCP registration was skipped.'; Write-InstallResult 'codex' 'skipped' 'Codex is not installed' }

    Write-InstallPhase 'claude_code'
    if ($Clients -notcontains 'ClaudeCode') { Write-Step 'Claude Code was not selected in setup.'; Write-InstallResult 'claude_code' 'skipped' 'not selected' }
    elseif (Get-OptionalCommand 'claude') {
        try {
            Register-ClaudeCodeMcpServer 'smart-connector' $bridge $arguments $legacyNames
            $detected++
            Write-InstallResult 'claude_code' 'ok'
        }
        catch {
            $registrationErrors += 'Claude Code: ' + $_.Exception.Message
            Write-Warning ('Claude Code registration failed; continuing with Claude Desktop: ' + $_.Exception.Message)
            Write-InstallResult 'claude_code' 'failed' 'see the setup log'
        }
    }
    else { Write-Step 'Claude Code was not detected, so its MCP registration was skipped.'; Write-InstallResult 'claude_code' 'skipped' 'Claude Code is not installed' }

    Write-InstallPhase 'claude_desktop'
    if ($Clients -notcontains 'ClaudeDesktop') { Write-Step 'Claude Desktop was not selected in setup.'; Write-InstallResult 'claude_desktop' 'skipped' 'not selected' }
    else {
        if ($InstallClaudeDesktopIfMissing -and -not $claudeDesktopInstallation) {
            $claudeDesktopInstallation = Install-ClaudeDesktop
        }
        if ($claudeDesktopInstallation -or $InstallClaudeDesktopIfMissing) {
            $desktopFailed = $false
            foreach ($configPath in @(Get-ClaudeDesktopConfigPaths)) {
                try {
                    Register-ClaudeDesktopMcpServer -Name 'Smart Connector' -Bridge $bridge -BridgeArguments $arguments -LegacyNames $claudeDesktopLegacyNames -ConfigPath $configPath
                    $detected++
                }
                catch {
                    $desktopFailed = $true
                    $registrationErrors += ('Claude Desktop at {0}: {1}' -f $configPath, $_.Exception.Message)
                    Write-Warning ('Could not update Claude config at {0}; continuing with other paths.' -f $configPath)
                }
            }
            Write-InstallResult 'claude_desktop' $(if ($desktopFailed) { 'failed' } else { 'ok' }) $(if ($desktopFailed) { 'see the setup log' } else { 'Claude restarts to load it' })
            Restart-ClaudeDesktopIfRunning -Processes $claudeDesktopProcesses -Installation $claudeDesktopInstallation
        }
        else {
            Write-Step 'Claude Desktop was not detected. Its local MCP registration was skipped; Claude web and mobile require the separate remote connector.'
            Write-InstallResult 'claude_desktop' 'skipped' 'Claude Desktop is not installed'
        }
    }

    if ($registrationErrors.Count -gt 0) {
        throw ('Some AI client registrations failed. Other registrations were still attempted. Repair these clients and run setup again: ' + ($registrationErrors -join '; '))
    }

    if ($detected -eq 0) {
        Write-Step 'No supported AI client was detected. Connector files and skills were installed; run Install / Repair after installing Codex or Claude.'
    }
}

function Get-AutoCadProgIds {
    $ids = @()
    try {
        $current = (Get-ItemProperty -LiteralPath 'Registry::HKEY_CLASSES_ROOT\AutoCAD.Application\CurVer' -ErrorAction Stop).'(default)'
        if ($current) { $ids += [string]$current }
    }
    catch { }
    try {
        $ids += @(Get-ChildItem 'Registry::HKEY_CLASSES_ROOT' -ErrorAction Stop |
            Where-Object { $_.PSChildName -match '^AutoCAD\.Application\.\d+(?:\.\d+)?$' } |
            Select-Object -ExpandProperty PSChildName)
    }
    catch { }
    @($ids + 'AutoCAD.Application' | Select-Object -Unique)
}

function Test-AutoCadSetup {
    $releases = @()
    $root = 'HKLM:\SOFTWARE\Autodesk\AutoCAD'
    if (Test-Path -LiteralPath $root) {
        $releases = @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue | Select-Object -ExpandProperty PSChildName)
    }
    if ($releases.Count -gt 0) {
        Write-Step ("AutoCAD installation detected: {0}" -f ($releases -join ', '))
    }
    else {
        Write-Step 'Full AutoCAD for Windows was not detected.'
    }

    $cad = $null
    foreach ($progId in Get-AutoCadProgIds) {
        try { $cad = [Runtime.InteropServices.Marshal]::GetActiveObject($progId); break } catch { }
    }
    if ($cad) {
        if ($cad.Documents.Count -gt 0) {
            $document = $cad.ActiveDocument
            Write-Step ("Live AutoCAD connection passed: version {0}; {1}; {2} layer(s)." -f $cad.Version, $document.Name, $document.Layers.Count)
        }
        else { Write-Step 'AutoCAD is running, but no drawing is open.' }
    }
    else { Write-Step 'AutoCAD is not currently available for a live test. Start AutoCAD and open a drawing.' }
}

function Get-AutoCadReleases {
    $root = 'HKLM:\SOFTWARE\Autodesk\AutoCAD'
    if (-not (Test-Path -LiteralPath $root)) { return @() }
    @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue | Select-Object -ExpandProperty PSChildName)
}

function Get-AutoCadButtonIcons {
    param([string]$AssetsDirectory)
    $images = @(Get-ChildItem -LiteralPath $AssetsDirectory -Filter 'sac-*.png' -File | Sort-Object Name)
    if ($images.Count -eq 0) { throw "The AutoCAD button icons are missing from $AssetsDirectory." }
    $images
}

# A .cuix is an OPC zip: the parts in the bundle's cuix-source folder plus the button icons from assets.
# Packed like Autodesk's own AppManager.cuix, whose ribbon icons show: PNGs not compressed (deflate level 0; .NET
# Framework cannot write stored entries) and every part listed in Menu_Package_Info.xml. Without that list AutoCAD
# 2025 showed our buttons as plain text.
function New-AutoCadCuix {
    param([string]$SourceDirectory, [string]$AssetsDirectory, [string]$Destination)
    Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
    $parts = @('[Content_Types].xml', '_rels/.rels', 'Header.cui', 'MenuGroup.cui', 'RibbonRoot.cui')
    $images = @(Get-AutoCadButtonIcons $AssetsDirectory)
    if (Test-Path -LiteralPath $Destination) { Remove-Item -LiteralPath $Destination -Force }
    $modified = [DateTimeOffset]::Now.ToString('o', [Globalization.CultureInfo]::InvariantCulture)
    $listed = @('Header.cui', 'MenuGroup.cui', 'RibbonRoot.cui') + @($images | ForEach-Object { $_.Name }) + 'VirtualMNRRoot' + 'Menu_Package_Info.xml'
    $packageInfo = "<?xml version=`"1.0`" encoding=`"utf-8`"?>`r`n<MenuPackageParts>`r`n" +
        (($listed | ForEach-Object { '  <PartData PartData_Name="/{0}" PartData_Modified="{1}" />' -f $_, $modified }) -join "`r`n") +
        "`r`n</MenuPackageParts>"
    $zip = [IO.Compression.ZipFile]::Open($Destination, 'Create')
    try {
        foreach ($part in $parts) {
            $source = Join-Path $SourceDirectory ($part -replace '/', '\')
            if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "CUIX part $part is missing from $SourceDirectory." }
            $null = [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $source, $part, [IO.Compression.CompressionLevel]::Optimal)
        }
        foreach ($image in $images) {
            $null = [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $image.FullName, $image.Name, [IO.Compression.CompressionLevel]::NoCompression)
        }
        $writer = New-Object IO.StreamWriter($zip.CreateEntry('Menu_Package_Info.xml', [IO.Compression.CompressionLevel]::Optimal).Open(), (New-Object Text.UTF8Encoding($false)))
        try { $writer.Write($packageInfo) } finally { $writer.Dispose() }
    }
    finally { $zip.Dispose() }
}

# AutoCAD keeps its own copy of a loaded partial menu in each release's roaming Support folder (seen on 2025).
# A stale copy can keep the old panel, so remove ours by its exact name; AutoCAD takes the new one from the bundle.
function Remove-AutoCadMenuCopies {
    param([string]$RoamingRoot = (Join-Path $env:APPDATA 'Autodesk'))
    foreach ($copy in @(Get-ChildItem -Path (Join-Path $RoamingRoot 'AutoCAD *\R*\*\Support\SmartAutodeskConnector.cuix') -File -ErrorAction SilentlyContinue)) {
        try { Remove-Item -LiteralPath $copy.FullName -Force -ErrorAction Stop }
        catch { Write-Warning ("Could not replace the old panel menu {0}; close AutoCAD and run setup again." -f $copy.FullName) }
    }
}

# AutoCAD keeps SECURELOAD and TRUSTEDPATHS per profile, in
# HKCU\Software\Autodesk\AutoCAD\<release>\<product>\Profiles\<profile>\Variables; the Profiles key's default
# value names the current profile (checked on AutoCAD 2025: <<Unnamed Profile>>). Returns the Variables keys of
# every profile, creating the current profile's key if AutoCAD has not written it yet.
function Get-AutoCadProfileVariableKeys {
    param([string]$RegistryRoot = 'HKCU:\Software\Autodesk\AutoCAD')
    foreach ($release in @(Get-ChildItem -LiteralPath $RegistryRoot -ErrorAction SilentlyContinue)) {
        foreach ($product in @(Get-ChildItem -LiteralPath $release.PSPath -ErrorAction SilentlyContinue)) {
            $profiles = Join-Path $product.PSPath 'Profiles'
            if (-not (Test-Path -LiteralPath $profiles)) { continue }
            $currentProfile = [string](Get-Item -LiteralPath $profiles).GetValue('')
            if ($currentProfile) {
                $currentVariables = Join-Path (Join-Path $profiles $currentProfile) 'Variables'
                if (-not (Test-Path -LiteralPath $currentVariables)) { New-Item -Path $currentVariables -Force | Out-Null }
            }
            foreach ($profile in @(Get-ChildItem -LiteralPath $profiles -ErrorAction SilentlyContinue)) {
                $variables = Join-Path $profile.PSPath 'Variables'
                if (Test-Path -LiteralPath $variables) { $variables }
            }
        }
    }
}

function Get-TrustedPathEntries {
    param([string]$Key)
    @(([string](Get-ItemProperty -LiteralPath $Key -ErrorAction SilentlyContinue).TRUSTEDPATHS) -split ';' | Where-Object { $_ })
}

# With SECURELOAD=1 AutoCAD asks before loading the LISP from %APPDATA% ("not located in a trusted folder",
# seen live on AutoCAD 2025). Trusting only the bundle's Contents folder removes that prompt (approved by the
# owner). Existing entries are kept; AutoCAD reads the value when it starts.
function Add-AutoCadTrustedPath {
    param([string]$Path, [string]$RegistryRoot = 'HKCU:\Software\Autodesk\AutoCAD')
    $updated = 0
    foreach ($variables in @(Get-AutoCadProfileVariableKeys $RegistryRoot)) {
        $entries = @(Get-TrustedPathEntries $variables)
        if (@($entries | Where-Object { $_.TrimEnd('\') -ieq $Path.TrimEnd('\') }).Count) { continue }
        Set-ItemProperty -LiteralPath $variables -Name TRUSTEDPATHS -Value (@($entries + $Path) -join ';')
        $updated++
    }
    $updated
}

function Remove-AutoCadTrustedPath {
    param([string]$Path, [string]$RegistryRoot = 'HKCU:\Software\Autodesk\AutoCAD')
    $updated = 0
    foreach ($variables in @(Get-AutoCadProfileVariableKeys $RegistryRoot)) {
        $entries = @(Get-TrustedPathEntries $variables)
        $kept = @($entries | Where-Object { $_.TrimEnd('\') -ine $Path.TrimEnd('\') })
        if ($kept.Count -eq $entries.Count) { continue }
        Set-ItemProperty -LiteralPath $variables -Name TRUSTEDPATHS -Value ($kept -join ';')
        $updated++
    }
    $updated
}

# Removes the panel and its trusted path. AutoCAD drops the panel at its next start.
function Uninstall-AutoCadBundle {
    param([string]$PluginsRoot = (Join-Path $env:APPDATA 'Autodesk\ApplicationPlugins'),
        [string]$RegistryRoot = 'HKCU:\Software\Autodesk\AutoCAD', [string]$RoamingRoot = (Join-Path $env:APPDATA 'Autodesk'))
    $target = Join-Path $PluginsRoot 'SmartAutodeskConnector.bundle'
    $null = Remove-AutoCadTrustedPath -Path (Join-Path $target 'Contents') -RegistryRoot $RegistryRoot
    Remove-AutoCadMenuCopies $RoamingRoot
    if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
    Write-Step 'Removed the AutoCAD Add-ins panel and its trusted path. Restart AutoCAD to finish.'
}

# Adds the Smart Connector panel to the AutoCAD Add-ins tab for this user (no admin rights needed).
# AutoCAD loads it at its next start.
function Install-AutoCadBundle {
    param([string]$Root, [string]$PluginsRoot = (Join-Path $env:APPDATA 'Autodesk\ApplicationPlugins'),
        [string]$RegistryRoot = 'HKCU:\Software\Autodesk\AutoCAD', [string]$RoamingRoot = (Join-Path $env:APPDATA 'Autodesk'))
    $source = Join-Path $Root 'src\autocad\SmartAutodeskConnector.bundle'
    $target = Join-Path $PluginsRoot 'SmartAutodeskConnector.bundle'
    $staging = Join-Path ([IO.Path]::GetTempPath()) ('SmartAutodeskConnector-' + [Guid]::NewGuid().ToString('N'))
    try {
        New-Item -ItemType Directory -Path (Join-Path $staging 'Contents') -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $source 'PackageContents.xml') -Destination $staging -Force
        Get-ChildItem -LiteralPath (Join-Path $source 'Contents') -File | Copy-Item -Destination (Join-Path $staging 'Contents') -Force
        New-AutoCadCuix -SourceDirectory (Join-Path $source 'Contents\cuix-source') -AssetsDirectory (Join-Path $Root 'assets') `
            -Destination (Join-Path $staging 'Contents\SmartAutodeskConnector.cuix')
        # Also beside the .cuix, in case AutoCAD looks the icons up as files on the bundle's paths.
        Get-AutoCadButtonIcons (Join-Path $Root 'assets') | Copy-Item -Destination (Join-Path $staging 'Contents') -Force
        Remove-AutoCadMenuCopies $RoamingRoot
        New-Item -ItemType Directory -Path (Join-Path $target 'Contents') -Force | Out-Null
        # File by file, so a copy AutoCAD has open is reported instead of leaving a half-removed bundle.
        Get-ChildItem -LiteralPath $staging -Recurse -File | ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $target $_.FullName.Substring($staging.Length).TrimStart('\')) -Force
        }
    }
    finally {
        if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue }
    }
    $trusted = Add-AutoCadTrustedPath -Path (Join-Path $target 'Contents') -RegistryRoot $RegistryRoot
    if ($trusted -gt 0) { Write-Step ("Added the panel's folder to AutoCAD's trusted paths in {0} profile(s)." -f $trusted) }
    Write-Step ("Installed the AutoCAD Add-ins panel at {0}. Restart AutoCAD to load it." -f $target)
}

function Install-AutoCadBundleStep {
    param([string]$Root)
    Write-InstallPhase 'autocad'
    $releases = @(Get-AutoCadReleases)
    if ($releases.Count -eq 0) {
        Write-Step 'AutoCAD was not detected, so its Add-ins panel was skipped.'
        Write-InstallResult 'autocad' 'skipped' 'AutoCAD is not installed'
        return
    }
    try {
        Install-AutoCadBundle $Root
        Write-InstallResult 'autocad' 'ok' 'restart AutoCAD to load it'
    }
    catch {
        # The connector itself works without the panel; report and carry on.
        Write-Warning ('The AutoCAD Add-ins panel could not be installed: ' + $_.Exception.Message)
        Write-InstallResult 'autocad' 'failed' 'close AutoCAD and run setup again'
    }
}

function Test-AutodeskRegistration {
    $codex = Get-OptionalCommand 'codex'
    if ($codex) {
        $registration = Invoke-External $codex @('mcp','get','smart-connector') -AllowFailure
        if ($registration.ExitCode -eq 0) { Write-Step 'Codex has the Smart Connector registration.' }
        else { Write-Step 'Smart Connector is not registered yet.' }
    }
    else { Write-Step 'Codex command was not detected.' }

    $claude = Get-OptionalCommand 'claude'
    if ($claude) {
        $registration = Invoke-External $claude @('mcp','get','smart-connector') -AllowFailure
        if ($registration.ExitCode -eq 0) { Write-Step 'Claude Code has the Smart Connector registration.' }
        else { Write-Step 'Smart Connector is not registered in Claude Code yet.' }
    }
    else { Write-Step 'Claude Code command was not detected.' }

    if (Test-ClaudeDesktopInstalled) {
        $configPath = Get-ClaudeDesktopConfigPath
        try {
            $config = Get-Content -LiteralPath $configPath -Raw -ErrorAction Stop | ConvertFrom-Json
            if ($config.mcpServers.PSObject.Properties['Smart Connector']) {
                Write-Step ("Claude Desktop has the Smart Connector registration at {0}." -f $configPath)
            }
            else { Write-Step 'Smart Connector is not registered in Claude Desktop yet.' }
        }
        catch { Write-Step 'Claude Desktop was detected, but its local MCP configuration is missing or invalid.' }
    }
    else { Write-Step 'Claude Desktop was not detected. Its local MCP registration is not installed.' }
}

# Start menu entry for the Smart Connector app (this user only). Never fails setup.
function Install-StartMenuShortcut {
    param([string]$Root)
    try {
        $programs = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
        New-Item -ItemType Directory -Path $programs -Force | Out-Null
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut((Join-Path $programs 'Smart Connector.lnk'))
        # The compiled Smart Connector program when it is installed (the setup .exe already points the entry at it);
        # otherwise the PowerShell app (an install taken from the repository). An entry already right is kept.
        $program = Join-Path $Root 'bin\SmartConnector.exe'
        $app = Join-Path $Root 'installer\SmartConnectorApp.ps1'
        $useProgram = Test-Path -LiteralPath $program -PathType Leaf
        $current = if ($useProgram) { [string]$shortcut.TargetPath -eq $program } else { [string]$shortcut.Arguments -like ('*' + $app + '*') }
        if ($current) {
            [void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell)
            Write-Step 'Smart Connector is in the Start menu.'
            return
        }
        if ($useProgram) {
            $shortcut.TargetPath = $program
            $shortcut.Arguments = 'app'
            $shortcut.WindowStyle = 1
        }
        else {
            $shortcut.TargetPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
            $shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "{0}"' -f $app
            $shortcut.WindowStyle = 7
        }
        $shortcut.WorkingDirectory = $env:LOCALAPPDATA
        $shortcut.IconLocation = (Join-Path $Root 'assets\logo.ico') + ',0'
        $shortcut.Description = 'Smart Connector for Autodesk Revit and AutoCAD'
        $shortcut.Save()
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell)
        Write-Step 'Added Smart Connector to the Start menu.'
    }
    catch { Write-Step ('The Start menu shortcut could not be created: {0}' -f $_.Exception.Message) }
}

function Test-Revit2024Installed {
    Test-Path -LiteralPath (Join-Path $env:ProgramFiles 'Autodesk\Revit 2024\RevitAPI.dll') -PathType Leaf
}

function Install-RevitAddin {
    param([string]$Root)

    $revitPath = Join-Path $env:ProgramFiles 'Autodesk\Revit 2024'
    if (-not (Test-Revit2024Installed)) {
        throw 'Revit 2024 was not detected. Install Revit 2024 before installing its MCP add-in.'
    }

    $buildScript = Join-Path $Root 'src\revit\build-revit-addin.ps1'
    $buildOutput = Join-Path ([IO.Path]::GetTempPath()) ("BimCadMcp-RevitBuild-" + [Guid]::NewGuid().ToString('N'))
    $assemblyDirectory = Join-Path $Root 'src\revit\bin\2024'
    New-Item -ItemType Directory -Path $assemblyDirectory -Force | Out-Null
    try {
        Write-Step 'Building the Revit 2024 add-in against the installed Revit API...'
        $built = Invoke-External 'powershell.exe' @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$buildScript,'-RevitVersion','2024','-OutputPath',$buildOutput)
        $null = $built
        $builtAssembly = Join-Path $buildOutput 'BimCadMcp.Revit.dll'
        if (-not (Test-Path -LiteralPath $builtAssembly -PathType Leaf)) { throw 'The Revit add-in DLL was not produced.' }

        # Revit locks loaded add-in DLLs. A content-addressed filename lets an update
        # finish safely while Revit is open; the manifest takes effect on next start.
        $assemblyHash = (Get-Sha256Hex -Path $builtAssembly).Substring(0, 12).ToLowerInvariant()
        $assembly = Join-Path $assemblyDirectory ("BimCadMcp.Revit.{0}.dll" -f $assemblyHash)
        Copy-Item -LiteralPath $builtAssembly -Destination $assembly -Force
    }
    finally {
        if (Test-Path -LiteralPath $buildOutput) { Remove-Item -LiteralPath $buildOutput -Recurse -Force -ErrorAction SilentlyContinue }
    }

    $manifestDirectory = Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2024'
    New-Item -ItemType Directory -Path $manifestDirectory -Force | Out-Null
    $manifestPath = Join-Path $manifestDirectory 'AutodeskMcpConnector.addin'
    $legacyManifestPath = Join-Path $manifestDirectory 'BimCadMcp.addin'
    $escapedAssembly = [Security.SecurityElement]::Escape($assembly)
    $manifest = @"
<?xml version="1.0" encoding="utf-8"?>
<RevitAddIns>
  <AddIn Type="Application">
    <Name>Smart Connector</Name>
    <Assembly>$escapedAssembly</Assembly>
    <AddInId>2DCE7E67-4495-4F3B-A740-3D7C9D2DA124</AddInId>
    <FullClassName>BimCadMcp.Revit.Application</FullClassName>
    <VendorId>BIMC</VendorId>
    <VendorDescription>Smart Connector for Codex and Claude</VendorDescription>
  </AddIn>
</RevitAddIns>
"@
    Set-Content -LiteralPath $manifestPath -Value $manifest -Encoding UTF8
    if (Test-Path -LiteralPath $legacyManifestPath -PathType Leaf) {
        Remove-Item -LiteralPath $legacyManifestPath -Force
    }
    Remove-OldRevitAddinBuilds -Directory $assemblyDirectory -Keep $assembly
    Write-Step ("Installed Revit add-in {0} and manifest {1}. Restart Revit to load it." -f (Split-Path -Leaf $assembly), $manifestPath)
}

function Remove-OldRevitAddinBuilds {
    param([string]$Directory, [string]$Keep)
    # Every build gets a content-hashed name; older ones pile up. A copy Revit still has loaded is
    # locked and simply stays until the next install.
    foreach ($old in @(Get-ChildItem -LiteralPath $Directory -Filter 'BimCadMcp.Revit.*.dll' -File -ErrorAction SilentlyContinue)) {
        if ([string]::Equals($old.FullName, $Keep, [StringComparison]::OrdinalIgnoreCase)) { continue }
        try { Remove-Item -LiteralPath $old.FullName -Force -ErrorAction Stop } catch { }
    }
}

function Test-RevitSetup {
    $installed = Test-Revit2024Installed
    if ($installed) { Write-Step 'Revit 2024 installation detected.' }
    else { Write-Step 'Revit 2024 was not detected.' }

    $manifest = Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2024\AutodeskMcpConnector.addin'
    if (Test-Path -LiteralPath $manifest -PathType Leaf) { Write-Step 'Smart Connector add-in is installed for Revit 2024.' }
    else { Write-Step 'Smart Connector add-in is not installed for Revit 2024 yet.' }
    if ($installed) { Write-Step 'In Revit, open the Smart Connector ribbon tab and click Status.' }

    $pipeName = 'BimCadMcp.Revit.2024'
    $sessionDirectory = Join-Path $env:LOCALAPPDATA 'BIM-CAD-MCP\runtime\revit-sessions'
    if (Test-Path -LiteralPath $sessionDirectory -PathType Container) {
        foreach ($sessionFile in @(Get-ChildItem -LiteralPath $sessionDirectory -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
            try {
                $session = Get-Content -LiteralPath $sessionFile.FullName -Raw | ConvertFrom-Json
                if ([string]$session.revit_version -eq '2024') {
                    $null = Get-Process -Id ([int]$session.pid) -ErrorAction Stop
                    $pipeName = [string]$session.pipe_name
                    break
                }
            }
            catch { }
        }
    }
    $client = New-Object IO.Pipes.NamedPipeClientStream('.', $pipeName, [IO.Pipes.PipeDirection]::InOut)
    try {
        $client.Connect(250)
        Write-Step ("Live Revit 2024 add-in connection is available on {0}." -f $pipeName)
    }
    catch { Write-Step 'Live Revit connection is not available. Restart Revit 2024 after installation and open a project.' }
    finally { $client.Dispose() }
}

function Remove-PlaintextFileSecurely {
    param([string]$Path)

    # Overwrite before deleting so the token does not stay in freed disk space. SSD wear levelling
    # can still retain old blocks, so deployment tools must not keep their own copies either.
    $item = Get-Item -LiteralPath $Path -Force
    if ($item.IsReadOnly) { $item.IsReadOnly = $false }
    $stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Write, [IO.FileShare]::None)
    $random = [Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $buffer = New-Object byte[] 4096
        $remaining = [int64]$item.Length
        while ($remaining -gt 0) {
            $count = [int][Math]::Min($remaining, $buffer.Length)
            $random.GetBytes($buffer)
            $stream.Write($buffer, 0, $count)
            $remaining -= $count
        }
        $stream.Flush($true)
    }
    finally {
        $random.Dispose()
        $stream.Dispose()
    }
    Remove-Item -LiteralPath $Path -Force
}

function Import-SkillServiceEnrollment {
    param(
        [string]$Root,
        [string]$Path = $EnrollmentPath,
        [string[]]$SearchDirectories = @($PSScriptRoot, (Split-Path -Parent $PSScriptRoot))
    )

    $serviceConfig = Join-Path $env:LOCALAPPDATA 'AutodeskMcpSkillCollection\service.json'
    $explicit = -not [string]::IsNullOrWhiteSpace($Path)
    $candidates = if ($explicit) { @($Path) } else {
        foreach ($directory in $SearchDirectories) {
            foreach ($name in @('enrollment.json', 'skill-service-device.json')) { Join-Path $directory $name }
        }
    }
    $file = $candidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
    if (-not $file) {
        if ($explicit) {
            Write-Step ("[ENROLLMENT_MISSING] Enrollment file not found: {0}. Central skill sharing stays pending." -f $Path)
        }
        elseif (Test-Path -LiteralPath $serviceConfig -PathType Leaf) {
            Write-Step '[ENROLLMENT_UNCHANGED] No enrollment file supplied. The existing central skill sharing enrollment is kept.'
            return 'AlreadyEnrolled'
        }
        else {
            Write-Step '[ENROLLMENT_PENDING] No enrollment file supplied. Central skill sharing waits for administrator enrollment.'
        }
        return 'Missing'
    }

    Write-Step ("Importing central skill sharing enrollment from {0}..." -f (Split-Path -Leaf $file))
    $status = 'Failed'
    try {
        $initializer = Join-Path $Root 'scripts\Initialize-SkillService.ps1'
        if (-not (Test-Path -LiteralPath $initializer -PathType Leaf)) { throw "Enrollment initializer is missing: $initializer" }
        # Parse here first: PowerShell JSON errors quote the input, which could copy the token into setup.log.
        try { $null = Get-Content -LiteralPath $file -Raw | ConvertFrom-Json }
        catch { throw 'The enrollment file is not valid JSON.' }
        $previous = if (Test-Path -LiteralPath $serviceConfig -PathType Leaf) { (Get-Item -LiteralPath $serviceConfig).LastWriteTimeUtc } else { $null }
        $output = @(& $initializer -ConfigPath $file)
        if (-not (Test-Path -LiteralPath $serviceConfig -PathType Leaf) -or
            ($previous -and (Get-Item -LiteralPath $serviceConfig).LastWriteTimeUtc -eq $previous)) {
            throw 'The initializer did not write service.json.'
        }
        $output | ForEach-Object { Write-Step ([string]$_) }
        Write-Step '[ENROLLMENT_OK] Central skill sharing is enrolled for this Windows user.'
        $status = 'Enrolled'
    }
    catch {
        Write-Step ("[ENROLLMENT_FAILED] {0} Central skill sharing stays pending. Ask your administrator for a new enrollment file." -f $_.Exception.Message)
    }
    finally {
        # The plaintext token must not stay on disk, even when the import failed.
        try {
            Remove-PlaintextFileSecurely -Path $file
            Write-Step '[ENROLLMENT_FILE_REMOVED] The plaintext enrollment file was overwritten and deleted.'
        }
        catch {
            Write-Step ("[ENROLLMENT_FILE_NOT_REMOVED] Delete the plaintext enrollment file manually: {0} ({1})" -f $file, $_.Exception.Message)
        }
    }
    return $status
}

function Register-SkillServiceDevice {
    param(
        [string]$Root,
        [string]$Name = $JoinName,
        [string]$Email = $JoinEmail,
        [string]$JoinConfigPath = (Join-Path $PSScriptRoot 'team-join.json')
    )

    $state = Join-Path $env:LOCALAPPDATA 'AutodeskMcpSkillCollection'
    if (Test-Path -LiteralPath (Join-Path $state 'service.json') -PathType Leaf) {
        Write-Step '[ENROLLMENT_UNCHANGED] This PC already belongs to the team skill service.'
        return 'AlreadyEnrolled'
    }
    $headers = @{}
    try {
        # Joining needs no team code. Without a join file the built-in service address is used; a code in an older
        # TEAM build's join file is still sent and ignored by the service.
        if (-not (Test-Path -LiteralPath $JoinConfigPath -PathType Leaf)) { $join = [pscustomobject]@{ service_url = $script:TeamServiceUrl } }
        else {
            try { $join = Get-Content -LiteralPath $JoinConfigPath -Raw | ConvertFrom-Json }
            catch { throw 'The team join file in this installer is damaged.' }
        }
        $uri = [Uri]([string]$join.service_url)
        if ($uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Query -or $uri.Fragment) { throw 'The team join file has an invalid service address.' }
        $versionPath = Join-Path $Root 'VERSION'
        $version = if (Test-Path -LiteralPath $versionPath) { (Get-Content -LiteralPath $versionPath -Raw).Trim() } else { 'unknown' }
        $profile = @{ name = $Name.Trim(); email = $Email.Trim(); pc_name = $env:COMPUTERNAME; windows_user = $env:USERNAME; connector_version = $version }
        if ($TermsVersion -match '^[0-9A-Za-z.-]{1,20}$') { $profile.terms_version = $TermsVersion }
        $body = $profile | ConvertTo-Json -Compress
        $headers = @{ 'X-Connector-Version' = $version }
        if (-not [string]::IsNullOrWhiteSpace([string]$join.join_code)) { $headers.Authorization = 'Bearer ' + [string]$join.join_code }
        Write-Step ("Joining the team skill service as {0}..." -f $Name.Trim())
        try {
            $device = Invoke-RestMethod -Uri ($uri.AbsoluteUri.TrimEnd('/') + '/v1/enroll') -Method Post -Headers $headers -UserAgent "Autodesk-MCP-Connector/$version" `
                -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 60
        }
        catch {
            $code = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
            # The service's error detail never contains secrets; it explains validation problems.
            $detail = ''
            try { $detail = [string]($_.ErrorDetails.Message | ConvertFrom-Json).detail } catch { }
            $reason = switch ($code) {
                0 { 'The team skill service could not be reached. Check the internet connection and run setup again.' }
                403 { 'The team join code was not accepted; this installer may be out of date. Ask your administrator for the current team installer.' }
                429 { 'Too many join attempts from this network. Wait an hour and run setup again.' }
                default { if ($detail) { $detail } else { "The team skill service refused the request (HTTP $code)." } }
            }
            throw $reason
        }
        New-Item -ItemType Directory -Path $state -Force | Out-Null
        $file = Join-Path $state ("enrollment-{0}.json" -f [guid]::NewGuid().ToString('N'))
        @{ service_url = $uri.AbsoluteUri.TrimEnd('/'); device_id = [string]$device.device_id; device_token = [string]$device.device_token } | ConvertTo-Json |
            Set-Content -LiteralPath $file -Encoding UTF8
        $device = $null
        # Reuses the admin-file path: DPAPI import, [ENROLLMENT_*] logging and secure deletion.
        return (Import-SkillServiceEnrollment -Root $Root -Path $file -SearchDirectories @())
    }
    catch {
        Write-Step ("[ENROLLMENT_FAILED] {0} Installation continues without central skill sharing." -f $_.Exception.Message)
        return 'Failed'
    }
    finally {
        $headers.Authorization = $null
        # Don't leave the team code in the permanent install; the installer itself is the only copy.
        $installedCopy = Join-Path $RepositoryPath 'installer\team-join.json'
        if (Test-Path -LiteralPath $installedCopy -PathType Leaf) { Remove-Item -LiteralPath $installedCopy -Force }
    }
}

if ($LibraryOnly) { return }

try {
    Write-Step ("Smart Connector - {0}" -f $Action)

    if ($Action -eq 'Collect') {
        $root = Get-Repository
        $collector = Join-Path $root 'scripts\collect-skills-for-review.ps1'
        Write-Step 'Collecting local user skills for review without uploading them...'
        $collected = Invoke-External 'powershell.exe' @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$collector,'-RepositoryRoot',$root)
        $null = $collected
        exit 0
    }

    if ($Action -eq 'CheckUpdate') {
        Remove-BackgroundTasks (Split-Path -Parent $PSScriptRoot)
        Test-ApprovedUpdate
        exit 0
    }

    if ($Action -eq 'EnableNotifications') {
        Enable-UpdateNotifications
        exit 0
    }

    if ($Action -eq 'DisableNotifications') {
        Disable-UpdateNotifications
        exit 0
    }

    if ($Action -eq 'ConnectGitHub') {
        $null = Get-PrivateRepositoryGit -AllowInstall:$InstallGitIfMissing
        Write-Step 'GitHub connection is ready. Skill submissions use your GitHub identity automatically; no name or email commands are needed.'
        exit 0
    }

    if ($Action -eq 'TeamStatus') {
        $installedManifest = Join-Path $RepositoryPath '.agents\skills'
        if (Test-Path -LiteralPath $installedManifest -PathType Container) {
            $root = (Resolve-Path -LiteralPath $RepositoryPath).Path
        }
        else {
            $root = Get-Repository
        }
        $submitter = Join-Path $root 'scripts\submit-team-knowledge.ps1'
        if (-not (Test-Path -LiteralPath $submitter -PathType Leaf)) { throw "Team submitter is missing: $submitter" }
        $git = Get-OptionalCommand 'git'
        if (-not $git -and $InstallGitIfMissing) {
            $git = Install-GitForWindows
        }
        if ($git) {
            Write-Step 'Git is installed.'
            try {
                $git = Get-PrivateRepositoryGit
                Write-Step 'Git authentication can access the private repository.'
            }
            catch { Write-Step $_.Exception.Message }
        }
        else { Write-Step 'Git is required for automatic team collection.' }
        Write-Step 'In Codex, ask: Use cad-team-knowledge-approval to enable my daily team knowledge collection.'
        Write-Step 'Codex will create the per-user daily automation only after that user asks for it.'
        exit 0
    }

    switch ($Action) {
        'UninstallAutoCadPanel' { Uninstall-AutoCadBundle }
        'Status' {
            if ($Product -in @('All','AutoCAD')) { Test-AutoCadSetup }
            if ($Product -in @('All','Revit')) { Test-RevitSetup }
            Test-AutodeskRegistration
        }
        'Test' {
            if ($Product -in @('All','AutoCAD')) { Test-AutoCadSetup }
            if ($Product -in @('All','Revit')) { Test-RevitSetup }
            Test-AutodeskRegistration
        }
        'Install' {
            $choices = Get-InstallChoices -AiClients $AiClients -Product $Product -ProductGiven $script:ProductGiven -Skills $Skills
            $Product = $choices.Product
            Write-Step ('Setting up: {0}; AI apps: {1}; team skills: {2}.' -f $(if ($Product -eq 'All') { 'Revit and AutoCAD' } else { $Product }), $(if ($choices.AiClients.Count) { $choices.AiClients -join ', ' } else { 'none' }), $(if ($choices.Skills) { 'yes' } else { 'no' }))
            Write-InstallPhase 'files'
            $root = Get-Repository
            Write-InstallResult 'files' 'ok'
            try { Save-InstallChoices $choices } catch { Write-Step ('The setup choices could not be saved: {0}' -f $_.Exception.Message) }
            Install-StartMenuShortcut $root
            # The connector files are required by every later step; each later step fails on its own.
            Invoke-InstallStep 'skills' {
                if (-not $choices.Skills) { Write-Step 'Team workflow skills were not selected in setup.'; Write-InstallResult 'skills' 'skipped' 'not selected' }
                else {
                    Install-Skills $root
                    Write-InstallResult 'skills' 'ok'
                }
            }
            Invoke-InstallStep 'team' {
                # An administrator's enrollment file wins; otherwise the setup window's details are used.
                try {
                    if ($JoinName -and $JoinEmail -and [string]::IsNullOrWhiteSpace($EnrollmentPath)) { $null = Register-SkillServiceDevice -Root $root }
                    else { $null = Import-SkillServiceEnrollment -Root $root }
                }
                finally {
                    # The setup .exe installs the TEAM join code with the other files; it never stays after setup.
                    $installedJoin = Join-Path $root 'installer\team-join.json'
                    if (Test-Path -LiteralPath $installedJoin -PathType Leaf) { Remove-Item -LiteralPath $installedJoin -Force }
                }
            }
            Invoke-InstallStep 'revit' {
                if ($Product -in @('All','Revit') -and (Test-Revit2024Installed)) {
                    Install-RevitAddin $root
                    Write-InstallResult 'revit' 'ok' 'restart Revit to load it'
                }
                elseif ($Product -in @('All','Revit')) {
                    Write-Step 'Revit 2024 was not detected, so its add-in was skipped.'
                    Write-InstallResult 'revit' 'skipped' 'Revit 2024 is not installed'
                }
            }
            if ($Product -in @('All','AutoCAD')) { Invoke-InstallStep 'autocad' { Install-AutoCadBundleStep $root } }
            Invoke-InstallStep 'updates' {
                Remove-BackgroundTasks $root -StopAgent
                $updateState = Read-UpdateState
                if ($AutoUpdates -eq 'Off') {
                    Disable-UpdateNotifications
                    Write-InstallResult 'updates' 'skipped' 'switched off in setup'
                }
                elseif ($AutoUpdates -eq 'On') {
                    Enable-UpdateNotifications
                    Write-InstallResult 'updates' 'ok'
                }
                elseif ($updateState.PSObject.Properties['notifications_user_disabled'] -and $updateState.notifications_user_disabled) {
                    Write-InstallResult 'updates' 'skipped' 'switched off in Settings'
                }
                else {
                    Enable-UpdateNotifications
                    Write-InstallResult 'updates' 'ok'
                }
            }
            Invoke-InstallStep 'codex' { Register-DetectedAiClients $root -Clients $choices.AiClients }
            # Setup has run to the end: Smart Connector opens normally from now on (Repair is in Components).
            $pendingMarker = Join-Path $root 'setup\setup-pending.txt'
            if (Test-Path -LiteralPath $pendingMarker -PathType Leaf) { Remove-Item -LiteralPath $pendingMarker -Force }
            # Final checks only report; they never undo a completed step.
            $script:CurrentInstallStep = ''
            foreach ($check in @(
                    $(if ($Product -in @('All','AutoCAD')) { { Test-AutoCadSetup } }),
                    $(if ($Product -in @('All','Revit')) { { Test-RevitSetup } }),
                    { Test-AutodeskRegistration }) | Where-Object { $_ }) {
                try { & $check } catch { Write-Step ("Check needs attention: {0}" -f $_.Exception.Message) }
            }
            if ($script:FailedInstallSteps.Count) {
                throw ("Setup finished, but these steps failed: {0}. The other steps were completed; see the setup log." -f (($script:FailedInstallSteps | Select-Object -Unique) -join ', '))
            }
            Write-Step 'Setup complete. Restart Codex, Claude, and any running Revit session, then open AutoCAD or Revit.'
        }
        'Update' {
            # Revit and AutoCAD keep connector files open; replacing the install folder under them fails.
            $openApps = Get-RunningAutodeskApps
            if ($openApps.Count) {
                Write-Output ("[{0}] [UPDATE_DEFERRED] {1} is open. Close it, and the update window installs the update." -f (Get-Date -Format 'HH:mm:ss'), ($openApps -join ' and '))
                break
            }
            $script:UpdateDownloaded = $false
            $choices = Get-InstallChoices -AiClients $AiClients -Product $Product -ProductGiven $script:ProductGiven -Skills $Skills
            $Product = $choices.Product
            $root = Get-Repository
            $null = Import-SkillServiceEnrollment -Root $root
            if (-not $script:UpdateDownloaded) {
                Write-Step 'No newer release was installed. Existing client registrations were preserved. Use Install / Repair to repair connections.'
                break
            }
            if ($choices.Skills) { Install-Skills $root }
            Install-StartMenuShortcut $root
            if ($Product -in @('All','Revit') -and (Test-Revit2024Installed)) {
                Install-RevitAddin $root
            }
            elseif ($Product -in @('All','Revit')) {
                Write-Step 'Revit 2024 was not detected, so its add-in was skipped.'
            }
            if ($Product -in @('All','AutoCAD')) { Install-AutoCadBundleStep $root }
            Register-DetectedAiClients $root -Clients $choices.AiClients
            Remove-BackgroundTasks $root -StopAgent
            Set-InstalledRelease -Version ((Get-Content -LiteralPath (Join-Path $root 'VERSION') -Raw).Trim()) `
                -Sha256 $(if ((Test-Path -LiteralPath (Join-Path $root '.bim-cad-source.json'))) {
                    [string]((Get-Content -LiteralPath (Join-Path $root '.bim-cad-source.json') -Raw | ConvertFrom-Json).sha256)
                } else { '' })
            Write-Output ("[{0}] [UPDATE_INSTALLED] Smart Connector {1} is installed." -f (Get-Date -Format 'HH:mm:ss'), (Get-InstalledVersion))
        }
    }
}
catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
}
