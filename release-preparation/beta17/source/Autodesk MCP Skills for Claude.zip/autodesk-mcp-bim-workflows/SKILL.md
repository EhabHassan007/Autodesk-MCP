---
name: autodesk-mcp-bim-workflows
description: Work with Revit, AutoCAD and other software through Smart Connector, using the team's approved workflow skills grouped by category.
---

# Smart Connector workflows

Use this skill for work performed through the local Smart Connector, and for the team's other approved workflows.

Read only the reference that matches the current task. Preserve the user's model and documentation intent, follow every MUST rule in the selected reference, and verify live model changes by reading the affected elements back through the connector. A skill supplies procedure; it does not grant permission for unrelated changes.

## Workflow references

### Revit

- [revit-architecture-model-review](references/revit/revit-architecture-model-review/SKILL.md): Review a Revit architectural model for spatial completeness, level and hosting integrity, modelling quality, documentation risks, and submission readiness. Use for model audits and architecture QA/QC; keep code or authority-specific compliance claims tied to supplied standards.
- [revit-areas-rooms-numbering](references/revit/revit-areas-rooms-numbering/SKILL.md): Coordinate Revit areas, rooms, linked-room naming, spatial numbering, terrace ownership, and door marks. Use when architectural spatial data must be derived or checked across host and linked models.
- [revit-csharp-runner](references/revit/revit-csharp-runner/SKILL.md): Run controlled C# through a Revit MCP execution tool with correct transaction context, batching, timeout recovery, failure logging, worksharing safeguards, and mandatory read-back.
- [revit-dimension-compliance](references/revit/revit-dimension-compliance/SKILL.md): Audit and, with phased approval, align Revit walls, columns, openings, and slab edges to clean grid or host references with dedicated check views and verification dimensions.
- [revit-dm-room-area-tags](references/revit/revit-dm-room-area-tags/SKILL.md): Update Room and Area names/tags in selected DM Revit views while preserving groups and keeping tags legible inside their spaces.
- [revit-dm-view-sheet-workflow](references/revit/revit-dm-view-sheet-workflow/SKILL.md): Duplicate selected Revit views and sheets for DM documentation, preserve detailing and overrides, apply naming/templates, and align grids and viewports.
- [revit-family-modelling](references/revit/revit-family-modelling/SKILL.md): Edit and reload Revit families safely and create difficult native modelling such as curved or sloped upstands, sloped floors, and railings. Use when family documents or nonstandard architectural geometry need controlled changes.
- [revit-grouped-dimension-dm](references/revit/revit-grouped-dimension-dm/SKILL.md): Safely update linear dimension types inside Revit detail groups across selected views or sheets while preserving groups, reusing one canonical DM copy per original group type, and cancelling every ungroup request.
- [revit-ifc-export-readiness](references/revit/revit-ifc-export-readiness/SKILL.md): Preflight a Revit model for IFC export by checking model segregation, storeys, rooms, classifications, required properties, coordinates, units, links, and export settings. Use before authority submission or IFC handover; validate the exported IFC separately.
- [revit-linked-coordinates](references/revit/revit-linked-coordinates/SKILL.md): Work safely with Revit links, nested and cloud links, linked-element tags, transforms, survey points, shared coordinates, and batch coordinate updates.
- [revit-linked-property-region](references/revit/revit-linked-property-region/SKILL.md): Create a Revit filled region from a PropertyLine selected inside a linked model, including curved and unordered boundary segments.
- [revit-linked-room-schedules](references/revit/revit-linked-room-schedules/SKILL.md): Build exact Revit schedules and Excel floor rollups for selected Room-name groups stored in linked architectural models.
- [revit-mcp-plugin-development](references/revit/revit-mcp-plugin-development/SKILL.md): Develop, register, build, test, update, and release Revit MCP tools and combined Autodesk connectors with guarded writes, portable setup, recoverable updates, and multi-client skill delivery.
- [revit-model-operations-recovery](references/revit/revit-model-operations-recovery/SKILL.md): Perform and recover from large Revit model operations with safe batching, worksharing checks, crash diagnostics, view-library extraction, and multi-session MCP ownership checks.
- [revit-multidiscipline-coordination](references/revit/revit-multidiscipline-coordination/SKILL.md): Coordinate architectural, structural, MEP, facade, interior, and landscape Revit models using links, shared coordinates, levels, grids, spatial checks, and traceable issue reporting. Use for federated-model review and clash triage.
- [revit-parking-width-dimensions](references/revit/revit-parking-width-dimensions/SKILL.md): Add native associative width dimensions to parking bays in specified Revit plan views through the Autodesk MCP connector, including rotated and mirrored bays. Preserve groups, reuse dimension styles, avoid duplicates, and verify coverage. Excludes changing bay sizes, clearance compliance reviews, and fabricated dimensions.
- [revit-plan-annotation-cleanup](references/revit/revit-plan-annotation-cleanup/SKILL.md): Clean room, area, door, window, and lift tags in Revit plan views while preserving readable placement, room containment, groups, and existing documentation. Use for annotation clash resolution and tag alignment.
- [revit-ramp-floor-edge-elements](references/revit/revit-ramp-floor-edge-elements/SKILL.md): Create and trim native Revit walls or pavement strips along selected sloped or curved ramp and floor edges while preserving the source geometry.
- [revit-read-write](references/revit/revit-read-write/SKILL.md): Inspect and edit a live Revit 2024 document through the local MCP add-in. Use for document information, levels, selected elements, element parameters, connection checks, and narrow parameter writes.
- [revit-template-standardisation](references/revit/revit-template-standardisation/SKILL.md): Capture a reference Revit plan's visual standard and roll it out through view templates, filters, dimension types, and tag families with test-view approval and reversible batches.
- [revit-view-filter-transfer](references/revit/revit-view-filter-transfer/SKILL.md): Build or use a Revit add-in that copies selected view-filter definitions from the active project to another open project without activating or saving the destination.
- [revit-views-sheets-workflows](references/revit/revit-views-sheets-workflows/SKILL.md): Manage Revit views, dependent plans, templates, sheets, schedules, legends, check images, and drafting-view reconstruction with dry runs, small batches, and documentation verification.

### AutoCAD

- [autocad-picture-to-dxf](references/autocad/autocad-picture-to-dxf/SKILL.md): Trace raster artwork or drawing references into editable 2D DXF outlines or curved color hatches, and repair generated DXFs. Excludes raster-only editing and automatic engineering reconstruction from photographs.
- [autocad-project-title-update](references/autocad/autocad-project-title-update/SKILL.md): Update AutoCAD project titles in TEXT/MTEXT or drawing custom properties such as PROJ.TITLE, preserving formatting and field links. Use connector tools and authorized background APIs without computer controls; excludes raster titles and unsupported block/xref edits.
- [autocad-read-write](references/autocad/autocad-read-write/SKILL.md): Inspect and edit a live full AutoCAD drawing on Windows through the repository's version-aware local MCP bridge. Use for drawing information, entities, text, layers, connection checks, and supported write operations.
- [autocad-zone-line-tracing](references/autocad/autocad-zone-line-tracing/SKILL.md): Draw and check zone / area outlines in AutoCAD that sit exactly on the plan's own linework (walls, ceiling outlines, track edges) with true arcs, shared edges between neighbouring zones, and no gaps or overlaps. Use when a user marks zones on a plan (sketch, screenshot, or their own polylines) and wants clean closed polylines per zone, or wants their zone polylines checked.
- [counter-detail-sheet-prep](references/autocad/counter-detail-sheet-prep/SKILL.md): Produce joinery counter detail packages (plan key, elevations, sections) as DXF/DWG, then prepare the AutoCAD sheet by annotating a layout in the style of a reference layout with short specification leaders, straight arrows, plain dimensions, levels, and section callouts. Use for reception/retail counter details and similar joinery sheets.
- [create-unfolded-walls](references/autocad/create-unfolded-walls/SKILL.md): Create connected unfolded wall elevations in AutoCAD from a selected or marked plan route, using measured CAD lengths and an existing dynamic wall block. Include specified door openings, preserve source geometry, and verify panels through background APIs without computer controls.
- [detail-generator](references/autocad/detail-generator/SKILL.md): Generate a draft construction detail in AutoCAD from a short brief, in millimetres: a vertical section through a reception counter (boards, plinth, Corian or stone top, optional raised bar, wheelchair-accessible variant) with hatches, dimensions, levels and notes. Use when asked to draw or revise a counter section, or to start a new joinery detail from parameters.
- [image-to-cad](references/autocad/image-to-cad/SKILL.md): Convert a supplied picture, sketch, or technical drawing into a CAD file with minimal conversational output. Use for image-to-DXF requests or when asked to save tokens while tracing an image into CAD.

### 3ds Max

_No approved skills yet._

### Other software

_No approved skills yet._

### LinkedIn and marketing

_No approved skills yet._

### Personal branding and corporate identity

_No approved skills yet._

### General and office

- [cad-skill-library](references/general/cad-skill-library/SKILL.md): Collect and review reusable AutoCAD, Revit, and other CAD/BIM Codex skills across computers, then add only user-approved candidates to the BIM-CAD---MCP GitHub library.
- [cad-team-knowledge-approval](references/general/cad-team-knowledge-approval/SKILL.md): Set up or run daily team collection of reusable CAD/BIM skills and lessons into private GitHub pull requests that require the repository owner's approval.
- [central-sharing-validation](references/general/central-sharing-validation/SKILL.md): Harmless central sharing validation fixture.
- [find-skills](references/general/find-skills/SKILL.md): Helps users discover and install agent skills when they ask questions like "how do I do X", "find a skill for X", "is there a skill that can...", or express interest in extending capabilities. This skill should be used when the user is looking for functionality that might exist as an installable skill.

### Not yet categorised

- [indesign-desktop-portfolio](references/uncategorized/indesign-desktop-portfolio/SKILL.md): Style or refine an architecture portfolio directly in desktop Adobe InDesign, including editable CV-based cover and introduction pages. Use for native INDD portfolio work and learned InDesign scripting techniques, not Adobe Express designs.
- [indesign-portfolio-presentation](references/uncategorized/indesign-portfolio-presentation/SKILL.md): Style an architecture or landscape architecture portfolio directly in desktop Adobe InDesign, including a CV-based cover and introduction pages. Use when the user supplies a CV for styled introductory pages, asks for a saved portfolio treatment, or provides an updated portfolio for restyling.
- [mem-search](references/uncategorized/mem-search/SKILL.md): Search what earlier Claude Code sessions did (prompts, files changed, commands run), as recorded locally by mem-lite. Use when the user asks what was done before, "last time", "yesterday", or which session touched a file.
- [skill-observer](references/uncategorized/skill-observer/SKILL.md): Runs quietly alongside every session to improve the user's skills. Logs corrections, stated preferences and gaps that a skill should have handled, spots repeated manual work that could become a new skill, and on request reviews the log and proposes skill updates for approval. Use at the start of every session, and when the user asks "any observations?", "review skill observations" or wants to improve or create skills from past work.
- [squeeze](references/uncategorized/squeeze/SKILL.md): Shrinks long command output before you read it, to save context and tokens. Use whenever a shell command is likely to print a lot — builds, installs, test suites, logs, git log, recursive listings, large JSON from APIs or tools — or when reading a big log or JSON file just to find what matters in it.
